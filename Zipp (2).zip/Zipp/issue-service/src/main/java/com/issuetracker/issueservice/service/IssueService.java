package com.issuetracker.issueservice.service;

import java.util.List;

import com.issuetracker.issueservice.dto.CreateIssueRequest;
import com.issuetracker.issueservice.dto.IssueResponse;
import com.issuetracker.issueservice.dto.UpdateIssueRequest;

/**
 * Business operations of the Issue Service.
 */
public interface IssueService {

    IssueResponse createIssue(CreateIssueRequest request);

    List<IssueResponse> getAllIssues();

    IssueResponse getIssueById(Integer issueId);

    /** Partial update: only the fields present in the request are changed. */
    IssueResponse updateIssue(Integer issueId, UpdateIssueRequest request);

    void deleteIssue(Integer issueId);

    /** Issues of one project (empty list if none). Called by the Project Service in Milestone 5. */
    List<IssueResponse> getIssuesByProject(Integer projectId);

    /** Issues created by one user ("owner" = created_by). */
    List<IssueResponse> getIssuesByOwner(Integer ownerId);

    /** Issues assigned to one user. Called by the User Service in Milestone 5. */
    List<IssueResponse> getIssuesByAssignee(Integer assigneeId);
}
