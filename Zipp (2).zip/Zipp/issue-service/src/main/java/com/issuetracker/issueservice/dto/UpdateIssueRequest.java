package com.issuetracker.issueservice.dto;

import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * JSON body of PUT /api/issues/{id}.
 *
 * Every field is OPTIONAL: only the fields present in the request are changed, the rest keep their
 * current value (a "partial update"). So an assignee can send just {"status": "DEVELOPMENT"}, and a
 * project owner can send {"assigneeId": 4, "priority": "HIGH"}.
 *
 * Week 4: projectId was added because the Edit Issue screen lets the owner pick another project
 * (the service checks that the new project exists). createdBy is still missing on purpose: the creator
 * of an issue never changes. If a client sends it anyway it is simply ignored.
 *
 * To clear an optional text field (description, tags), send it as an empty string "".
 */
public record UpdateIssueRequest(

        @Size(min = 5, max = 100, message = "Summary must be 5 to 100 characters")
        @Pattern(regexp = ValidationPatterns.SUMMARY, message = ValidationPatterns.SUMMARY_MESSAGE)
        String summary,

        @Size(max = 500, message = "Description must be at most 500 characters")
        String description,

        @Positive(message = "Project id must be a positive number")
        Integer projectId,

        @Positive(message = "Assignee id must be a positive number")
        Integer assigneeId,

        Priority priority,

        IssueStatus status,

        IssueType type,

        @Positive(message = "Sprint must be a positive number")
        Integer sprint,

        @Min(value = 0, message = "Story points cannot be negative")
        @Max(value = 100, message = "Story points must be at most 100")
        Integer storyPoint,

        @Size(max = 255, message = "Tags must be at most 255 characters")
        String tags) {

    /** True when the client sent no field at all (e.g. an empty body {}), so there is nothing to update. */
    public boolean hasNoChanges() {
        return summary == null && description == null && projectId == null && assigneeId == null && priority == null
                && status == null && type == null && sprint == null && storyPoint == null && tags == null;
    }
}
