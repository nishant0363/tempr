package com.issuetracker.issueservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.issuetracker.issueservice.entity.Issue;

/**
 * Data access for the issue table. Spring Data JPA writes the implementation from the method names.
 * The three look-ups below back the endpoints that OTHER services call (Milestone 5).
 */
@Repository
public interface IssueRepository extends JpaRepository<Issue, Integer> {

    /** GET /api/issues/project/{projectId}   ->  WHERE project = ? */
    List<Issue> findByProjectId(Integer projectId);

    /** GET /api/issues/owner/{ownerId}       ->  WHERE created_by = ? */
    List<Issue> findByCreatedBy(Integer createdBy);

    /** GET /api/issues/assignee/{assigneeId} ->  WHERE assignee = ? */
    List<Issue> findByAssigneeId(Integer assigneeId);
}
