package com.issuetracker.issueservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client for the User Service (Milestone 5). Used to check that an issue's creator is a
 * PROJECT_OWNER and its assignee is an ASSIGNEE before the issue is saved.
 *
 * If the user does not exist, the User Service answers 404 and Feign throws FeignException.NotFound,
 * which IssueServiceImpl turns into a 400 with a clear message.
 */
@FeignClient(name = "user-service")
public interface UserClient {

    @GetMapping("/api/users/{userId}")
    UserDto getUserById(@PathVariable("userId") Integer userId);
}
