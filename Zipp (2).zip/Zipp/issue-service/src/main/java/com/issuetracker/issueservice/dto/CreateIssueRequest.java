package com.issuetracker.issueservice.dto;

import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * JSON body of POST /api/issues.
 *
 * Inputs from the case study: summary, project ID, description, priority, assignee ID, status,
 * created date, last updated date and comments. Differences (see README assumptions):
 *  - created/last-updated dates are NOT inputs: the server sets them, so clients cannot fake them
 *  - comments are left out (no Comment Service, no comments column in the DB design)
 *  - createdBy, type, sprint, storyPoint and tags come from the DB design
 *
 * Week 4: the limits follow the React case study (summary 5-100 characters with only - / | . as special
 * characters, description up to 500, sprint a number). Rules that only matter for the screen, such as
 * "story points must be a prime number", stay in the React form.
 */
public record CreateIssueRequest(

        @Schema(example = "Search returns duplicate results",
                description = "5 to 100 characters: letters, numbers, spaces and - / | .")
        @NotBlank(message = "Summary is required")
        @Size(min = 5, max = 100, message = "Summary must be 5 to 100 characters")
        @Pattern(regexp = ValidationPatterns.SUMMARY, message = ValidationPatterns.SUMMARY_MESSAGE)
        String summary,

        @Schema(example = "Searching for invoice shows every result twice on the orders page")
        @Size(max = 500, message = "Description must be at most 500 characters")
        String description,

        @Schema(example = "1", description = "Id of the project the issue belongs to")
        @NotNull(message = "Project id is required")
        @Positive(message = "Project id must be a positive number")
        Integer projectId,

        @Schema(example = "3", description = "User id of the assignee (must be an ASSIGNEE)")
        @NotNull(message = "Assignee id is required")
        @Positive(message = "Assignee id must be a positive number")
        Integer assigneeId,

        @Schema(example = "1", description = "User id of the creator (must be a PROJECT_OWNER)")
        @NotNull(message = "Created-by user id is required")
        @Positive(message = "Created-by user id must be a positive number")
        Integer createdBy,

        @Schema(example = "MEDIUM", description = "LOW, MEDIUM or HIGH")
        @NotNull(message = "Priority is required (LOW, MEDIUM or HIGH)")
        Priority priority,

        @Schema(example = "TO_DO", description = "Optional - TO_DO if not given. TO_DO, DEVELOPMENT, TESTING or COMPLETED")
        IssueStatus status,

        @Schema(example = "BUG", description = "BUG, TASK or STORY")
        @NotNull(message = "Type is required (BUG, TASK or STORY)")
        IssueType type,

        @Schema(example = "2", description = "Optional sprint number (1, 2, 3 ...)")
        @Positive(message = "Sprint must be a positive number")
        Integer sprint,

        @Schema(example = "3", description = "Optional - 0 if not given")
        @Min(value = 0, message = "Story points cannot be negative")
        @Max(value = 100, message = "Story points must be at most 100")
        Integer storyPoint,

        @Schema(example = "search,backend", description = "Optional comma-separated labels")
        @Size(max = 255, message = "Tags must be at most 255 characters")
        String tags) {
}
