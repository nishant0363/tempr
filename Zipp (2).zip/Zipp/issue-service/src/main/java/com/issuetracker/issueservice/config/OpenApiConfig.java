package com.issuetracker.issueservice.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

/**
 * Title and description shown at the top of the Swagger UI page (http://localhost:8083/swagger-ui.html).
 * springdoc builds the list of endpoints by itself from the controllers; this bean only adds the header.
 *
 * Milestone 7: the "Servers" drop-down at the top of Swagger UI chooses where "Execute" sends the request:
 *  - straight to this service (port 8083)
 *  - through the API Gateway (port 8080), which finds this service in Eureka and forwards the request.
 * The same endpoint can therefore be demonstrated both ways from one page.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI issueServiceOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Issue Service API")
                        .version("1.0")
                        .description("Issue Tracking System - create, read, update and delete issues"))
                .servers(List.of(
                        new Server().url("http://localhost:8083").description("Directly to the Issue Service (port 8083)"),
                        new Server().url("http://localhost:8080").description("Through the API Gateway (port 8080)")));
    }
}
