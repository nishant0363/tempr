package com.issuetracker.projectservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.issuetracker.projectservice.entity.Project;

/**
 * Data access for the project table. Spring Data JPA writes the implementation;
 * each method below is a "derived query" built from the method name.
 */
@Repository
public interface ProjectRepository extends JpaRepository<Project, Integer> {

    /** GET /api/projects/owner/{ownerId}  ->  SELECT * FROM project WHERE project_owner = ? */
    List<Project> findByProjectOwnerId(Integer projectOwnerId);

    /** Used by the "issues by project name" endpoint (Milestone 5). */
    Optional<Project> findByProjectNameIgnoreCase(String projectName);

    /** Create: is this name already used by any project? */
    boolean existsByProjectNameIgnoreCase(String projectName);

    /** Update: is this name used by a DIFFERENT project? (A project may keep its own name.) */
    boolean existsByProjectNameIgnoreCaseAndIdNot(String projectName, Integer id);
}
