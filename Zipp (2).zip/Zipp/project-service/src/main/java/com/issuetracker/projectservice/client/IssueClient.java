package com.issuetracker.projectservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client for the Issue Service (Milestone 5 - inter-service communication).
 *
 * Only the interface is written; Spring Cloud OpenFeign generates the code that finds "issue-service"
 * in Eureka, sends GET http://<its address>/api/issues/project/{projectId} and converts the JSON answer.
 * If the Issue Service is down, a FeignException is thrown and GlobalExceptionHandler answers 503.
 */
@FeignClient(name = "issue-service")
public interface IssueClient {

    @GetMapping("/api/issues/project/{projectId}")
    List<IssueDto> getIssuesByProject(@PathVariable("projectId") Integer projectId);
}
