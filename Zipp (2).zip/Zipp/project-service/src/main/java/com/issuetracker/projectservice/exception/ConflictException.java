package com.issuetracker.projectservice.exception;

/**
 * Thrown when a request cannot be done in the current state of the data,
 * e.g. deleting a project that still has issues. GlobalExceptionHandler turns it into 409 Conflict.
 */
public class ConflictException extends RuntimeException {

    public ConflictException(String message) {
        super(message);
    }
}
