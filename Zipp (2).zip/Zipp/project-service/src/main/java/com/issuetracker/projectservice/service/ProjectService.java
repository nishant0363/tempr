package com.issuetracker.projectservice.service;

import java.util.List;

import com.issuetracker.projectservice.client.IssueDto;
import com.issuetracker.projectservice.dto.ProjectRequest;
import com.issuetracker.projectservice.dto.ProjectResponse;

/**
 * Business operations of the Project Service.
 * The controller depends on this interface, not on the implementation class (loose coupling,
 * and easy to replace with a mock in tests).
 */
public interface ProjectService {

    ProjectResponse createProject(ProjectRequest request);

    List<ProjectResponse> getAllProjects();

    ProjectResponse getProjectById(Integer projectId);

    ProjectResponse updateProject(Integer projectId, ProjectRequest request);

    void deleteProject(Integer projectId);

    /** All projects owned by one user (empty list if they own none). */
    List<ProjectResponse> getProjectsByOwner(Integer ownerId);

    // ---------- Milestone 5: inter-service communication (asks the Issue Service) ----------

    /** Issues of the project with this id. 404 if the project does not exist. */
    List<IssueDto> getIssuesOfProject(Integer projectId);

    /** Issues of the project with this name (not case-sensitive). 404 if no such project. */
    List<IssueDto> getIssuesOfProjectByName(String projectName);
}
