package com.issuetracker.projectservice.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.issuetracker.projectservice.client.IssueClient;
import com.issuetracker.projectservice.client.IssueDto;
import com.issuetracker.projectservice.client.UserDto;
import com.issuetracker.projectservice.client.UserServiceClient;
import com.issuetracker.projectservice.dto.ProjectRequest;
import com.issuetracker.projectservice.dto.ProjectResponse;
import com.issuetracker.projectservice.entity.Project;
import com.issuetracker.projectservice.exception.ConflictException;
import com.issuetracker.projectservice.exception.DuplicateResourceException;
import com.issuetracker.projectservice.exception.InvalidRequestException;
import com.issuetracker.projectservice.exception.ResourceNotFoundException;
import com.issuetracker.projectservice.repository.ProjectRepository;
import com.issuetracker.projectservice.service.ProjectService;

/**
 * Business logic for projects: the rules live here, not in the controller.
 *
 * Rules:
 *  - project name is required and unique (ignoring upper/lower case)
 *  - end date, if given, must not be before the start date
 *  - unknown project id -> 404
 *  - Milestone 5: the owner must exist in the User Service and be a PROJECT_OWNER (RestTemplate call)
 *  - Milestone 5: a project that still has issues cannot be deleted (Feign call to the Issue Service)
 *
 * Methods that call another service are not @Transactional: a database transaction should not stay open
 * while waiting for a network answer. Each repository call still runs in its own transaction.
 */
@Service
public class ProjectServiceImpl implements ProjectService {

    private static final Logger log = LoggerFactory.getLogger(ProjectServiceImpl.class);

    private final ProjectRepository projectRepository;
    private final UserServiceClient userServiceClient;   // RestTemplate -> User Service
    private final IssueClient issueClient;               // Feign        -> Issue Service

    /** Constructor injection (see UserServiceImpl for why). */
    @Autowired
    public ProjectServiceImpl(ProjectRepository projectRepository, UserServiceClient userServiceClient,
            IssueClient issueClient) {
        this.projectRepository = projectRepository;
        this.userServiceClient = userServiceClient;
        this.issueClient = issueClient;
    }

    @Override
    public ProjectResponse createProject(ProjectRequest request) {
        String name = request.projectName().trim();

        // Cheap local checks first, the remote call last
        if (projectRepository.existsByProjectNameIgnoreCase(name)) {
            throw new DuplicateResourceException("A project named '" + name + "' already exists");
        }
        validateDates(request.startDate(), request.endDate());
        checkOwnerIsProjectOwner(request.projectOwnerId());

        Project project = new Project();
        copyRequestToProject(request, name, project);

        Project saved = projectRepository.save(project);
        log.info("Project created: id={}, owner={}", saved.getId(), saved.getProjectOwnerId());
        return ProjectResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectResponse> getAllProjects() {
        return projectRepository.findAll()
                .stream()
                .map(ProjectResponse::from)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ProjectResponse getProjectById(Integer projectId) {
        return ProjectResponse.from(findProjectOrThrow(projectId));
    }

    @Override
    public ProjectResponse updateProject(Integer projectId, ProjectRequest request) {
        Project project = findProjectOrThrow(projectId);
        String name = request.projectName().trim();

        // The project may keep its own name, but must not take another project's name
        if (projectRepository.existsByProjectNameIgnoreCaseAndIdNot(name, projectId)) {
            throw new DuplicateResourceException("Another project named '" + name + "' already exists");
        }
        validateDates(request.startDate(), request.endDate());
        // Only ask the User Service when the owner actually changes
        if (!request.projectOwnerId().equals(project.getProjectOwnerId())) {
            checkOwnerIsProjectOwner(request.projectOwnerId());
        }

        copyRequestToProject(request, name, project);

        Project saved = projectRepository.save(project);
        log.info("Project updated: id={}", saved.getId());
        return ProjectResponse.from(saved);
    }

    @Override
    public void deleteProject(Integer projectId) {
        if (!projectRepository.existsById(projectId)) {
            throw new ResourceNotFoundException("Project not found with id " + projectId);
        }
        // There are no foreign keys between databases, so WE must stop issues being left pointing
        // at a project that no longer exists
        List<IssueDto> issues = issueClient.getIssuesByProject(projectId);
        if (!issues.isEmpty()) {
            throw new ConflictException("Project " + projectId + " still has " + issues.size()
                    + " issue(s). Delete those issues first, then delete the project");
        }
        projectRepository.deleteById(projectId);
        log.info("Project deleted: id={}", projectId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectResponse> getProjectsByOwner(Integer ownerId) {
        return projectRepository.findByProjectOwnerId(ownerId)
                .stream()
                .map(ProjectResponse::from)
                .toList();
    }

    // ---------- Milestone 5: issues from the Issue Service ----------

    @Override
    public List<IssueDto> getIssuesOfProject(Integer projectId) {
        // 1. Our own data: does the project exist? (404 if not - clearer than an empty list)
        if (!projectRepository.existsById(projectId)) {
            throw new ResourceNotFoundException("Project not found with id " + projectId);
        }
        // 2. The Issue Service owns the issues, so we ask it (Feign call through Eureka)
        return issueClient.getIssuesByProject(projectId);
    }

    @Override
    public List<IssueDto> getIssuesOfProjectByName(String projectName) {
        Project project = projectRepository.findByProjectNameIgnoreCase(projectName.trim())
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with name '" + projectName + "'"));
        return issueClient.getIssuesByProject(project.getId());
    }

    // ---------- helpers ----------

    private Project findProjectOrThrow(Integer projectId) {
        return projectRepository.findById(projectId)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id " + projectId));
    }

    /** Two-field rule, so it cannot be a simple annotation on one field. */
    private void validateDates(LocalDate startDate, LocalDate endDate) {
        if (endDate != null && endDate.isBefore(startDate)) {
            throw new InvalidRequestException("End date (" + endDate + ") cannot be before start date (" + startDate + ")");
        }
    }

    /**
     * Asks the User Service (RestTemplate) whether the owner exists and is a PROJECT_OWNER.
     * A bad owner id is a problem with the request body, so it is a 400 (not a 404, which is for the URL).
     */
    private void checkOwnerIsProjectOwner(Integer ownerId) {
        UserDto owner = userServiceClient.findUserById(ownerId)
                .orElseThrow(() -> new InvalidRequestException("Project owner: no user exists with id " + ownerId));
        if (!owner.isProjectOwner()) {
            throw new InvalidRequestException("Project owner: user " + ownerId + " (" + owner.name() + ") is "
                    + owner.role() + ", but only a PROJECT_OWNER can own a project");
        }
    }

    /** Create and update set the same fields, so the copying is written once. */
    private void copyRequestToProject(ProjectRequest request, String trimmedName, Project project) {
        project.setProjectName(trimmedName);
        project.setProjectOwnerId(request.projectOwnerId());
        project.setStartDate(request.startDate());
        project.setEndDate(request.endDate());
    }
}
