package com.issuetracker.projectservice.exception;

/**
 * Thrown when another microservice this service depends on cannot be reached.
 * GlobalExceptionHandler turns it into 503 Service Unavailable, and nothing is saved.
 */
public class ServiceUnavailableException extends RuntimeException {

    public ServiceUnavailableException(String serviceName) {
        super(serviceName + " is not available right now. Please try again later");
    }
}
