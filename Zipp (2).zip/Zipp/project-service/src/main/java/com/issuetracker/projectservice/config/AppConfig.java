package com.issuetracker.projectservice.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * General beans for this service.
 */
@Configuration
public class AppConfig {

    /**
     * RestTemplate used to call the User Service (see client.UserServiceClient).
     *
     * @LoadBalanced lets us write URLs with a service NAME (http://user-service/...) instead of a fixed
     * host and port. Before each request, Spring Cloud LoadBalancer looks up the running instances of
     * "user-service" in Eureka and picks one (round robin if there are several) - client-side load balancing.
     */
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
