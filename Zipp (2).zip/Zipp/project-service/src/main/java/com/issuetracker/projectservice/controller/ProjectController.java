package com.issuetracker.projectservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.issuetracker.projectservice.client.IssueDto;
import com.issuetracker.projectservice.dto.MessageResponse;
import com.issuetracker.projectservice.dto.ProjectRequest;
import com.issuetracker.projectservice.dto.ProjectResponse;
import com.issuetracker.projectservice.dto.ProjectSavedResponse;
import com.issuetracker.projectservice.service.ProjectService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/**
 * REST endpoints of the Project Service (section 7.2 of the case study).
 *
 * Convention used in every service:
 *  - reads (GET) return the data itself with 200 OK
 *  - writes (POST / PUT / DELETE) return a confirmation message (+ the saved object), with
 *    201 Created for POST and 200 OK for PUT and DELETE
 *  - errors are thrown by the service and turned into JSON by GlobalExceptionHandler
 */
@RestController
@RequestMapping("/api/projects")
@Tag(name = "Project Service", description = "Create, read, update and delete projects")
public class ProjectController {

    private final ProjectService projectService;

    @Autowired
    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    /** GET /api/projects -> 200 OK with every project. */
    @Operation(summary = "Retrieve a list of all projects")
    @GetMapping
    public ResponseEntity<List<ProjectResponse>> getAllProjects() {
        return ResponseEntity.ok(projectService.getAllProjects());
    }

    /** POST /api/projects -> 201 Created. 400 for invalid input or a bad owner, 409 if the name is taken. */
    @Operation(summary = "Create a new project")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)   // only tells Swagger the success code is 201; ResponseEntity sets it
    public ResponseEntity<ProjectSavedResponse> createProject(@Valid @RequestBody ProjectRequest request) {
        ProjectResponse created = projectService.createProject(request);
        ProjectSavedResponse body = new ProjectSavedResponse(
                "Project created successfully with id " + created.projectId(), created);
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    /** GET /api/projects/{projectId} -> 200 OK, or 404. */
    @Operation(summary = "Retrieve details of a specific project by project ID")
    @GetMapping("/{projectId}")
    public ResponseEntity<ProjectResponse> getProjectById(@PathVariable("projectId") Integer projectId) {
        return ResponseEntity.ok(projectService.getProjectById(projectId));
    }

    /** PUT /api/projects/{projectId} -> 200 OK with the updated project. 400, 404 or 409 on errors. */
    @Operation(summary = "Update details of a specific project by project ID")
    @PutMapping("/{projectId}")
    public ResponseEntity<ProjectSavedResponse> updateProject(@PathVariable("projectId") Integer projectId,
            @Valid @RequestBody ProjectRequest request) {
        ProjectResponse updated = projectService.updateProject(projectId, request);
        return ResponseEntity.ok(new ProjectSavedResponse("Project updated successfully", updated));
    }

    /** DELETE /api/projects/{projectId} -> 200 OK with a message, 404 if unknown, 409 if it still has issues. */
    @Operation(summary = "Delete a specific project by project ID")
    @DeleteMapping("/{projectId}")
    public ResponseEntity<MessageResponse> deleteProject(@PathVariable("projectId") Integer projectId) {
        projectService.deleteProject(projectId);
        return ResponseEntity.ok(new MessageResponse("Project " + projectId + " deleted successfully"));
    }

    /** GET /api/projects/owner/{ownerId} -> 200 OK with that owner's projects (empty list if none). */
    @Operation(summary = "Retrieve projects owned by a specific user by owner ID")
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<ProjectResponse>> getProjectsByOwner(@PathVariable("ownerId") Integer ownerId) {
        return ResponseEntity.ok(projectService.getProjectsByOwner(ownerId));
    }

    // ---------- Milestone 5: inter-service communication (data comes from the Issue Service) ----------

    /** GET /api/projects/{projectId}/issues -> 200 OK with the project's issues, 404 if no such project. */
    @Operation(summary = "Retrieve issues within a specific project by project ID (inter-service: calls Issue Service)")
    @GetMapping("/{projectId}/issues")
    public ResponseEntity<List<IssueDto>> getIssuesOfProject(@PathVariable("projectId") Integer projectId) {
        return ResponseEntity.ok(projectService.getIssuesOfProject(projectId));
    }

    /** GET /api/projects/projectName/{projectName}/issues -> same, but the project is found by name. */
    @Operation(summary = "Retrieve issues within a specific project by project name (inter-service: calls Issue Service)")
    @GetMapping("/projectName/{projectName}/issues")
    public ResponseEntity<List<IssueDto>> getIssuesOfProjectByName(@PathVariable("projectName") String projectName) {
        return ResponseEntity.ok(projectService.getIssuesOfProjectByName(projectName));
    }
}
