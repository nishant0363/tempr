package com.issuetracker.projectservice.exception;

/**
 * Thrown when a request is well-formed JSON but breaks a business rule that annotations cannot express,
 * e.g. an end date before the start date. GlobalExceptionHandler turns it into 400 Bad Request.
 */
public class InvalidRequestException extends RuntimeException {

    public InvalidRequestException(String message) {
        super(message);
    }
}
