package com.issuetracker.projectservice.dto;

/**
 * A plain confirmation message, e.g. {"message": "Project 3 deleted successfully"}.
 * Used by DELETE, where there is no object left to return.
 */
public record MessageResponse(String message) {
}
