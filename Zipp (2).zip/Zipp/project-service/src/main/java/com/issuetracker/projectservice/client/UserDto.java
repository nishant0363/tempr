package com.issuetracker.projectservice.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The part of the User Service's UserResponse JSON that this service needs to check a project owner.
 * Other fields (email, profile ...) are ignored thanks to @JsonIgnoreProperties(ignoreUnknown = true).
 * The role is a plain String ("PROJECT_OWNER" / "ASSIGNEE") - this service does not share the User
 * Service's Role enum, because microservices share no code.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record UserDto(
        Integer userId,
        String name,
        String role) {

    public static final String PROJECT_OWNER = "PROJECT_OWNER";

    public boolean isProjectOwner() {
        return PROJECT_OWNER.equals(role);
    }
}
