package com.issuetracker.projectservice.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.issuetracker.projectservice.client.IssueClient;
import com.issuetracker.projectservice.client.IssueDto;
import com.issuetracker.projectservice.client.UserDto;
import com.issuetracker.projectservice.client.UserServiceClient;
import com.issuetracker.projectservice.dto.ProjectRequest;
import com.issuetracker.projectservice.dto.ProjectResponse;
import com.issuetracker.projectservice.entity.Project;
import com.issuetracker.projectservice.exception.ConflictException;
import com.issuetracker.projectservice.exception.DuplicateResourceException;
import com.issuetracker.projectservice.exception.InvalidRequestException;
import com.issuetracker.projectservice.exception.ResourceNotFoundException;
import com.issuetracker.projectservice.exception.ServiceUnavailableException;
import com.issuetracker.projectservice.repository.ProjectRepository;

/**
 * Unit tests for ProjectServiceImpl.
 * The repository and both clients to other services are Mockito mocks, so neither MySQL nor the
 * User/Issue services need to be running.
 */
@ExtendWith(MockitoExtension.class)
class ProjectServiceImplTest {

    private static final LocalDate START = LocalDate.of(2026, 10, 1);
    private static final LocalDate END = LocalDate.of(2026, 12, 31);

    private static final UserDto PRIYA_OWNER = new UserDto(1, "Priya Sharma", "PROJECT_OWNER");
    private static final UserDto RAHUL_ASSIGNEE = new UserDto(3, "Rahul Verma", "ASSIGNEE");

    @Mock
    private ProjectRepository projectRepository;

    @Mock
    private UserServiceClient userServiceClient;

    @Mock
    private IssueClient issueClient;

    private ProjectServiceImpl projectService;

    @BeforeEach
    void setUp() {
        projectService = new ProjectServiceImpl(projectRepository, userServiceClient, issueClient);
    }

    /** Helper: a project as it would come back from the database. */
    private Project existingProject(Integer id, String name) {
        Project project = new Project();
        project.setId(id);
        project.setProjectName(name);
        project.setProjectOwnerId(1);
        project.setStartDate(START);
        project.setEndDate(END);
        return project;
    }

    private IssueDto sampleIssue() {
        return new IssueDto(1, "Login page crashes", null, 1, 3, 1, "HIGH", "TO_DO", "BUG",
                1, 3, null, null, null);
    }

    // ---------- create ----------

    @Test
    void createProject_validRequest_savesAndReturnsProjectWithId() {
        when(projectRepository.existsByProjectNameIgnoreCase("Payments Gateway")).thenReturn(false);
        when(userServiceClient.findUserById(1)).thenReturn(Optional.of(PRIYA_OWNER));
        when(projectRepository.save(any(Project.class))).thenAnswer(invocation -> {
            Project toSave = invocation.getArgument(0);
            toSave.setId(10);
            return toSave;
        });

        ProjectResponse response = projectService.createProject(
                new ProjectRequest("  Payments Gateway ", 1, START, END));

        assertThat(response.projectId()).isEqualTo(10);
        assertThat(response.projectName()).isEqualTo("Payments Gateway");   // trimmed
        assertThat(response.projectOwnerId()).isEqualTo(1);
    }

    @Test
    void createProject_withoutEndDate_isAllowed() {
        when(projectRepository.existsByProjectNameIgnoreCase("Open Ended")).thenReturn(false);
        when(userServiceClient.findUserById(1)).thenReturn(Optional.of(PRIYA_OWNER));
        when(projectRepository.save(any(Project.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ProjectResponse response = projectService.createProject(new ProjectRequest("Open Ended", 1, START, null));

        assertThat(response.endDate()).isNull();
    }

    @Test
    void createProject_endDateBeforeStartDate_throwsInvalidRequestWithoutCallingUserService() {
        when(projectRepository.existsByProjectNameIgnoreCase("Backwards")).thenReturn(false);

        assertThatThrownBy(() -> projectService.createProject(
                new ProjectRequest("Backwards", 1, END, START)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("cannot be before start date");
        verifyNoInteractions(userServiceClient);
        verify(projectRepository, never()).save(any(Project.class));
    }

    @Test
    void createProject_nameAlreadyUsed_throwsDuplicate() {
        when(projectRepository.existsByProjectNameIgnoreCase("Customer Portal")).thenReturn(true);

        assertThatThrownBy(() -> projectService.createProject(
                new ProjectRequest("Customer Portal", 1, START, END)))
                .isInstanceOf(DuplicateResourceException.class);
        verify(projectRepository, never()).save(any(Project.class));
    }

    @Test
    void createProject_ownerDoesNotExist_throwsInvalidRequest() {
        when(projectRepository.existsByProjectNameIgnoreCase("New Project")).thenReturn(false);
        when(userServiceClient.findUserById(99)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> projectService.createProject(new ProjectRequest("New Project", 99, START, END)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("no user exists with id 99");
        verify(projectRepository, never()).save(any(Project.class));
    }

    @Test
    void createProject_ownerIsAnAssignee_throwsInvalidRequest() {
        when(projectRepository.existsByProjectNameIgnoreCase("New Project")).thenReturn(false);
        when(userServiceClient.findUserById(3)).thenReturn(Optional.of(RAHUL_ASSIGNEE));

        assertThatThrownBy(() -> projectService.createProject(new ProjectRequest("New Project", 3, START, END)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("only a PROJECT_OWNER can own a project");
        verify(projectRepository, never()).save(any(Project.class));
    }

    @Test
    void createProject_userServiceDown_throwsServiceUnavailableAndSavesNothing() {
        when(projectRepository.existsByProjectNameIgnoreCase("New Project")).thenReturn(false);
        when(userServiceClient.findUserById(1)).thenThrow(new ServiceUnavailableException("user-service"));

        assertThatThrownBy(() -> projectService.createProject(new ProjectRequest("New Project", 1, START, END)))
                .isInstanceOf(ServiceUnavailableException.class);
        verify(projectRepository, never()).save(any(Project.class));
    }

    // ---------- read ----------

    @Test
    void getProjectById_unknownId_throwsNotFound() {
        when(projectRepository.findById(99)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> projectService.getProjectById(99))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessage("Project not found with id 99");
    }

    @Test
    void getProjectsByOwner_returnsOnlyThatOwnersProjects() {
        when(projectRepository.findByProjectOwnerId(1)).thenReturn(List.of(existingProject(1, "Customer Portal")));

        List<ProjectResponse> projects = projectService.getProjectsByOwner(1);

        assertThat(projects).hasSize(1);
        assertThat(projects.get(0).projectName()).isEqualTo("Customer Portal");
    }

    // ---------- update ----------

    @Test
    void updateProject_sameOwner_doesNotCallUserService() {
        when(projectRepository.findById(1)).thenReturn(Optional.of(existingProject(1, "Customer Portal")));
        when(projectRepository.existsByProjectNameIgnoreCaseAndIdNot("Customer Portal", 1)).thenReturn(false);
        when(projectRepository.save(any(Project.class))).thenAnswer(invocation -> invocation.getArgument(0));

        LocalDate newEnd = LocalDate.of(2027, 1, 31);
        ProjectResponse response = projectService.updateProject(1,
                new ProjectRequest("Customer Portal", 1, START, newEnd));

        assertThat(response.endDate()).isEqualTo(newEnd);
        verifyNoInteractions(userServiceClient);
    }

    @Test
    void updateProject_newOwnerIsAnAssignee_throwsInvalidRequest() {
        when(projectRepository.findById(1)).thenReturn(Optional.of(existingProject(1, "Customer Portal")));
        when(projectRepository.existsByProjectNameIgnoreCaseAndIdNot("Customer Portal", 1)).thenReturn(false);
        when(userServiceClient.findUserById(3)).thenReturn(Optional.of(RAHUL_ASSIGNEE));

        assertThatThrownBy(() -> projectService.updateProject(1,
                new ProjectRequest("Customer Portal", 3, START, END)))
                .isInstanceOf(InvalidRequestException.class);
        verify(projectRepository, never()).save(any(Project.class));
    }

    @Test
    void updateProject_takingAnotherProjectsName_throwsDuplicate() {
        when(projectRepository.findById(1)).thenReturn(Optional.of(existingProject(1, "Customer Portal")));
        when(projectRepository.existsByProjectNameIgnoreCaseAndIdNot("Inventory Revamp", 1)).thenReturn(true);

        assertThatThrownBy(() -> projectService.updateProject(1,
                new ProjectRequest("Inventory Revamp", 1, START, END)))
                .isInstanceOf(DuplicateResourceException.class);
    }

    @Test
    void updateProject_unknownId_throwsNotFound() {
        when(projectRepository.findById(99)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> projectService.updateProject(99,
                new ProjectRequest("Anything", 1, START, END)))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- delete ----------

    @Test
    void deleteProject_withoutIssues_deletes() {
        when(projectRepository.existsById(3)).thenReturn(true);
        when(issueClient.getIssuesByProject(3)).thenReturn(List.of());

        projectService.deleteProject(3);

        verify(projectRepository).deleteById(3);
    }

    @Test
    void deleteProject_thatStillHasIssues_throwsConflictAndDeletesNothing() {
        when(projectRepository.existsById(1)).thenReturn(true);
        when(issueClient.getIssuesByProject(1)).thenReturn(List.of(sampleIssue()));

        assertThatThrownBy(() -> projectService.deleteProject(1))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("still has 1 issue(s)");
        verify(projectRepository, never()).deleteById(any());
    }

    @Test
    void deleteProject_unknownId_throwsNotFoundAndDeletesNothing() {
        when(projectRepository.existsById(99)).thenReturn(false);

        assertThatThrownBy(() -> projectService.deleteProject(99))
                .isInstanceOf(ResourceNotFoundException.class);
        verify(projectRepository, never()).deleteById(any());
        verifyNoInteractions(issueClient);
    }

    // ---------- Milestone 5: issues of a project ----------

    @Test
    void getIssuesOfProjectByName_findsProjectThenAsksIssueService() {
        when(projectRepository.findByProjectNameIgnoreCase("customer portal"))
                .thenReturn(Optional.of(existingProject(1, "Customer Portal")));
        when(issueClient.getIssuesByProject(1)).thenReturn(List.of(sampleIssue()));

        List<IssueDto> issues = projectService.getIssuesOfProjectByName("customer portal");

        assertThat(issues).hasSize(1);
    }

    @Test
    void getIssuesOfProject_unknownProject_throwsNotFoundWithoutCallingIssueService() {
        when(projectRepository.existsById(99)).thenReturn(false);

        assertThatThrownBy(() -> projectService.getIssuesOfProject(99))
                .isInstanceOf(ResourceNotFoundException.class);
        verifyNoInteractions(issueClient);
    }
}
