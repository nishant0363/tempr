import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { getDashboardPath } from './paths';

/**
 * Route guard for the Login and Signup pages: they are only for visitors who are NOT logged in.
 * A logged-in user who opens /login is sent straight to their own dashboard.
 */
export function GuestRoute() {
  const { user } = useAuth();

  if (user !== null) {
    return <Navigate to={getDashboardPath(user.role)} replace />;
  }
  return <Outlet />;
}
