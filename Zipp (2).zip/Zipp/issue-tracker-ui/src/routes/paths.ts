import type { Role } from '../models/User';

/**
 * Every URL of the app in one place, so a path is never typed twice (a typo would break a link).
 * "as const" makes each value a fixed literal type instead of just "string".
 */
export const PATHS = {
  LOGIN: '/login',
  SIGNUP: '/signup',
  OWNER_DASHBOARD: '/owner/dashboard',
  CREATE_PROJECT: '/owner/projects/new',
  CREATE_ISSUE: '/owner/issues/new',
  OWNER_ISSUE_DETAILS: '/owner/issues/:issueId',      // ":issueId" is a URL parameter (useParams)
  EDIT_ISSUE: '/owner/issues/:issueId/edit',
  ASSIGNEE_DASHBOARD: '/assignee/dashboard',
  ASSIGNEE_ISSUE_DETAILS: '/assignee/issues/:issueId',
} as const;

/** The home page of each role: where a user goes after logging in. */
export function getDashboardPath(role: Role): string {
  return role === 'PROJECT_OWNER' ? PATHS.OWNER_DASHBOARD : PATHS.ASSIGNEE_DASHBOARD;
}

/** Owner dashboard showing one project's board: /owner/dashboard?projectId=2 */
export function getProjectBoardPath(projectId: number): string {
  return `${PATHS.OWNER_DASHBOARD}?projectId=${projectId}`;
}

/** Project Owner's Issue Details page of one issue: /owner/issues/7 */
export function getOwnerIssuePath(issueId: number): string {
  return `/owner/issues/${issueId}`;
}

/** Edit Issue page of one issue: /owner/issues/7/edit */
export function getEditIssuePath(issueId: number): string {
  return `/owner/issues/${issueId}/edit`;
}

/** Assignee's Issue Details page of one issue: /assignee/issues/7 */
export function getAssigneeIssuePath(issueId: number): string {
  return `/assignee/issues/${issueId}`;
}
