import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import type { Role } from '../models/User';
import { PATHS, getDashboardPath } from './paths';

/** Props of ProtectedRoute: which role may open the pages inside it. */
interface ProtectedRouteProps {
  allowedRole: Role;
}

/**
 * Route guard for pages that need a logged-in user with a certain role (see App.tsx).
 *  - nobody logged in          -> go to the Login page
 *  - logged in with another role -> go to that user's own dashboard (an Assignee cannot open owner pages)
 *  - otherwise                 -> show the requested page (<Outlet /> = "the child route goes here")
 * replace = true replaces the history entry, so the Back button does not return to the blocked page.
 */
export function ProtectedRoute({ allowedRole }: ProtectedRouteProps) {
  const { user } = useAuth();

  if (user === null) {
    return <Navigate to={PATHS.LOGIN} replace />;
  }
  if (user.role !== allowedRole) {
    return <Navigate to={getDashboardPath(user.role)} replace />;
  }
  return <Outlet />;
}
