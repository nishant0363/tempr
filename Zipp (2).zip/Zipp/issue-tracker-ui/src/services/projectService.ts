import apiClient from './apiClient';
import type { Project, ProjectRequest, ProjectSavedResponse } from '../models/Project';

/** All calls to the Project Service (through the gateway: /api/projects/...). */
const projectService = {
  /** GET /api/projects - every project (the Assignee's pages use it to show project names). */
  async getAllProjects(): Promise<Project[]> {
    const response = await apiClient.get<Project[]>('/projects');
    return response.data;
  },

  /** GET /api/projects/owner/{ownerId} - the projects owned by one Project Owner (empty list if none). */
  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    const response = await apiClient.get<Project[]>(`/projects/owner/${ownerId}`);
    return response.data;
  },

  /**
   * POST /api/projects - creates a project. The backend answers 201 with the saved project, 400 when a
   * value is invalid or the owner is not a Project Owner, and 409 when the name is already used.
   */
  async createProject(request: ProjectRequest): Promise<ProjectSavedResponse> {
    const response = await apiClient.post<ProjectSavedResponse>('/projects', request);
    return response.data;
  },
};

export default projectService;
