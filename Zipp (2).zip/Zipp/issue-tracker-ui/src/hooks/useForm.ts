import { useState } from 'react';
import type { ChangeEvent, Dispatch, FocusEvent, SetStateAction } from 'react';

/**
 * The values of a form: one string per field. HTML inputs always give strings (even type="number"),
 * so the form keeps strings and the page converts them (e.g. to numbers) only when it sends the request.
 */
export type FormValues = Record<string, string>;

/** One error message per field. A field without a message (undefined) is valid. */
export type FormErrors<T extends FormValues> = Partial<Record<keyof T, string>>;

/** A function that checks ALL the values and returns the error message of every invalid field. */
export type ValidateFunction<T extends FormValues> = (values: T) => FormErrors<T>;

/** The elements a form field can be. */
type FieldElement = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;

/** Everything useForm gives back to a page (or to a shared fields component such as IssueFormFields). */
export interface UseFormResult<T extends FormValues> {
  values: T;
  errors: FormErrors<T>;
  isValid: boolean;
  handleChange: (event: ChangeEvent<FieldElement>) => void;
  handleBlur: (event: FocusEvent<FieldElement>) => void;
  getError: (field: keyof T) => string | undefined;
  reset: (newValues?: T) => void;
  setValues: Dispatch<SetStateAction<T>>;
}

/**
 * Reusable form logic for every form in the app (Login, Signup and the later Create/Edit forms).
 *
 * This is the React version of a "reactive form": the form's values and its validation rules live in
 * code (state + a validate function), and every input is "controlled" - it shows the value from state
 * and reports each key press back through handleChange.
 *
 *  - errors are calculated from the values on every render (not stored), so they are never out of date
 *  - an error is only SHOWN once the user has interacted with that field (typed in it or left it)
 *  - isValid tells the page whether the submit button may be enabled
 *
 * <T extends FormValues> is a generic, like List<T> in Java: each form says which fields it has, and
 * TypeScript then checks every field name we use (form.values.email, form.getError('email')).
 */
export function useForm<T extends FormValues>(initialValues: T, validate: ValidateFunction<T>): UseFormResult<T> {
  /** Current value of every field. */
  const [values, setValues] = useState<T>(initialValues);

  /** Fields the user has interacted with. Errors are only shown for these. */
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});

  /** Error message of every invalid field, worked out from the current values. */
  const errors: FormErrors<T> = validate(values);

  /** True when no field has an error message. */
  const isValid: boolean = Object.values(errors).every((message) => !message);

  /** onChange of every field: store the new value (the input's name attribute says which field). */
  function handleChange(event: ChangeEvent<FieldElement>): void {
    const { name, value } = event.target;
    setValues((previous) => ({ ...previous, [name]: value }));
    setTouched((previous) => ({ ...previous, [name]: true }));
  }

  /** onBlur of every field: the user has left the field, so its error may now be shown. */
  function handleBlur(event: FocusEvent<FieldElement>): void {
    const { name } = event.target;
    setTouched((previous) => ({ ...previous, [name]: true }));
  }

  /** The message to SHOW under a field: its error, but only after the user has interacted with it. */
  function getError(field: keyof T): string | undefined {
    return touched[field] ? errors[field] : undefined;
  }

  /** Puts every field back to the given values (blank by default) and hides all messages. */
  function reset(newValues: T = initialValues): void {
    setValues(newValues);
    setTouched({});
  }

  return { values, errors, isValid, handleChange, handleBlur, getError, reset, setValues };
}
