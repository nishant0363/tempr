import { useEffect, useState } from 'react';
import type { Issue } from '../models/Issue';
import { getErrorMessage } from '../services/apiClient';
import issueService from '../services/issueService';

/** The answer of one load, remembered TOGETHER with the id it belongs to. */
interface IssueLoadResult {
  issueId: number;
  issue: Issue | null;   // null when the load failed
  error: string;         // '' when the load worked
}

/** What useIssue gives back to a page. */
export interface UseIssueResult {
  issue: Issue | null;
  loading: boolean;
  error: string;
  reload: () => void;                   // "Try again"
  replaceIssue: (issue: Issue) => void; // show the issue the server returned after a save
}

/**
 * Loads one issue by its id (Issue Details, Edit Issue and, in Milestone 6, the Assignee's details).
 *
 * Every result is stored with the id it belongs to. If the user opens another issue (the id in the URL
 * changes), the stored result no longer matches, so "loading" is true until the new issue arrives -
 * the old issue is never shown under the new id.
 */
export function useIssue(issueId: number): UseIssueResult {
  /** Last answer (with its id), or null before the first answer. */
  const [result, setResult] = useState<IssueLoadResult | null>(null);
  /** Increased by reload() to load again. */
  const [reloadCount, setReloadCount] = useState(0);

  /** Ids come from the URL, so "abc" or "-1" are possible - those are not even requested. */
  const isValidId = Number.isInteger(issueId) && issueId > 0;

  useEffect(() => {
    if (!isValidId) {
      return;
    }
    let ignore = false;   // an outdated answer must not overwrite newer state
    issueService
      .getIssueById(issueId)
      .then((loadedIssue) => {
        if (!ignore) {
          setResult({ issueId, issue: loadedIssue, error: '' });
        }
      })
      .catch((loadError: unknown) => {
        if (!ignore) {
          setResult({ issueId, issue: null, error: getErrorMessage(loadError) });
        }
      });
    return () => {
      ignore = true;
    };
  }, [issueId, isValidId, reloadCount]);

  /** Forgets the current result (spinner again) and loads once more. */
  function reload(): void {
    setResult(null);
    setReloadCount((count) => count + 1);
  }

  /** Puts a fresh copy of the issue (e.g. returned by a save) on screen without loading it again. */
  function replaceIssue(updatedIssue: Issue): void {
    setResult({ issueId: updatedIssue.issueId, issue: updatedIssue, error: '' });
  }

  if (!isValidId) {
    return { issue: null, loading: false, error: 'This address does not contain a valid issue number.', reload, replaceIssue };
  }

  /** The result for THIS id only. */
  const current = result !== null && result.issueId === issueId ? result : null;
  return {
    issue: current?.issue ?? null,
    loading: current === null,
    error: current?.error ?? '',
    reload,
    replaceIssue,
  };
}
