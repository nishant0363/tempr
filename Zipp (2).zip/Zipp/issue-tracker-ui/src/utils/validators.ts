/**
 * Validation rules shared by the forms. Each function checks ONE field and returns its error message,
 * or undefined when the value is valid. The forms combine them in their own validate functions.
 *
 * The patterns are the same as the backend's (SignUpRequest in the User Service), so the browser
 * and the server always agree on what is valid.
 */

/** name@domain.tld - letters, digits and . _ % + - before the @, and a domain ending in 2+ letters. */
export const EMAIL_PATTERN = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

/**
 * 8-64 characters with at least one lower-case letter, one upper-case letter, one digit and one
 * special character. Each (?=.*X) is a "look-ahead": it checks that X appears somewhere.
 */
export const PASSWORD_PATTERN = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,64}$/;

/** http:// or https://, no spaces, ending in an image extension (an optional ?query is allowed). The i = ignore case. */
export const IMAGE_URL_PATTERN = /^https?:\/\/\S+\.(png|jpe?g|gif|webp|svg)(\?\S*)?$/i;

/**
 * Text that may contain letters, digits, spaces and only these special characters: - / | .
 * (case study rule for the project name and the issue summary; the backend checks the same pattern).
 */
export const SAFE_TEXT_PATTERN = /^[A-Za-z0-9 ./|-]+$/;

/** Username: 3-30 letters, digits, dot, underscore or hyphen - no spaces (same pattern as the backend). */
export const USERNAME_PATTERN = /^[A-Za-z0-9._-]{3,30}$/;

/** Longest name the backend accepts. */
const NAME_MAX_LENGTH = 100;

/** Required text: must contain something other than spaces. */
export function validateRequired(value: string, label: string): string | undefined {
  return value.trim() === '' ? `${label} is required` : undefined;
}

/** Name: required, at most 100 characters. */
export function validateName(value: string): string | undefined {
  if (value.trim() === '') {
    return 'Name is required';
  }
  if (value.trim().length > NAME_MAX_LENGTH) {
    return `Name must be at most ${NAME_MAX_LENGTH} characters`;
  }
  return undefined;
}

/** Username: required, 3-30 characters, letters/numbers/dot/underscore/hyphen. Uniqueness is checked by the server. */
export function validateUsername(value: string): string | undefined {
  if (value.trim() === '') {
    return 'Username is required';
  }
  if (!USERNAME_PATTERN.test(value.trim())) {
    return 'Username must be 3-30 characters: letters, numbers, dot, underscore or hyphen (no spaces)';
  }
  return undefined;
}

/** Email: required and in the format name@example.com. */
export function validateEmail(value: string): string | undefined {
  if (value.trim() === '') {
    return 'Email is required';
  }
  if (!EMAIL_PATTERN.test(value.trim())) {
    return 'Enter a valid email address, e.g. name@example.com';
  }
  return undefined;
}

/** Password: required and in the "proper password format" described above. */
export function validatePassword(value: string): string | undefined {
  if (value === '') {
    return 'Password is required';
  }
  if (!PASSWORD_PATTERN.test(value)) {
    return 'Password must be 8-64 characters with an uppercase letter, a lowercase letter, a number and a special character';
  }
  return undefined;
}

/** Profile image: optional, but when filled in it must be a valid image URL. */
export function validateImageUrl(value: string): string | undefined {
  if (value.trim() === '') {
    return undefined;   // no photo - the app shows the user's initials instead
  }
  if (!IMAGE_URL_PATTERN.test(value.trim())) {
    return 'Enter an image URL starting with http:// or https:// and ending in .png, .jpg, .jpeg, .gif, .webp or .svg';
  }
  return undefined;
}

/** Any drop-down: something must be chosen (the empty placeholder entry has the value ''). */
export function validateSelection(value: string, what: string): string | undefined {
  return value === '' ? `Please select ${what}` : undefined;
}

/** Role: one must be chosen from the drop-down. */
export function validateRole(value: string): string | undefined {
  return validateSelection(value, 'your role');
}

/**
 * Required text with a length range that may only contain letters, digits, spaces and - / | .
 * Used for the project name and the issue summary.
 */
export function validateSafeText(
  value: string,
  label: string,
  minLength: number,
  maxLength: number,
): string | undefined {
  const text = value.trim();
  if (text === '') {
    return `${label} is required`;
  }
  if (text.length < minLength) {
    return `${label} must be at least ${minLength} characters`;
  }
  if (text.length > maxLength) {
    return `${label} must be at most ${maxLength} characters`;
  }
  if (!SAFE_TEXT_PATTERN.test(text)) {
    return `${label} can only contain letters, numbers, spaces and - / | .`;
  }
  return undefined;
}

/**
 * End date: required, and not before the start date. Date inputs give "yyyy-MM-dd" text, which sorts
 * correctly as plain text, so a string comparison is enough.
 */
export function validateEndDate(startDate: string, endDate: string): string | undefined {
  if (endDate === '') {
    return 'End date is required';
  }
  if (startDate !== '' && endDate < startDate) {
    return 'End date cannot be before the start date';
  }
  return undefined;
}

/**
 * Optional text: may be left empty, but when filled in it must have between minLength and maxLength
 * characters (e.g. the issue description: optional, 10-500 characters).
 */
export function validateOptionalLength(
  value: string,
  label: string,
  minLength: number,
  maxLength: number,
): string | undefined {
  const text = value.trim();
  if (text === '') {
    return undefined;
  }
  if (text.length < minLength) {
    return `${label} must be at least ${minLength} characters (or leave it empty)`;
  }
  if (text.length > maxLength) {
    return `${label} must be at most ${maxLength} characters`;
  }
  return undefined;
}

/** Digits only - no sign, no decimal point, no spaces. */
const WHOLE_NUMBER_PATTERN = /^\d+$/;

/** Required whole number between 1 and max (e.g. the sprint: 1, 2, 3 ...). */
export function validatePositiveWholeNumber(value: string, label: string, max: number): string | undefined {
  const text = value.trim();
  if (text === '') {
    return `${label} is required`;
  }
  if (!WHOLE_NUMBER_PATTERN.test(text) || Number(text) < 1 || Number(text) > max) {
    return `${label} must be a whole number from 1 to ${max}`;
  }
  return undefined;
}

/**
 * True for prime numbers (2, 3, 5, 7, 11 ...): numbers above 1 that can only be divided by 1 and themselves.
 * Trying divisors up to the square root is enough: if n = a x b, one of a and b is at most sqrt(n).
 */
export function isPrime(n: number): boolean {
  if (!Number.isInteger(n) || n < 2) {
    return false;
  }
  for (let divisor = 2; divisor * divisor <= n; divisor++) {
    if (n % divisor === 0) {
      return false;
    }
  }
  return true;
}

/** Story points: required, a prime number, and at most max (the backend accepts up to 100). */
export function validatePrimeNumber(value: string, label: string, max: number): string | undefined {
  const text = value.trim();
  if (text === '') {
    return `${label} is required`;
  }
  if (!WHOLE_NUMBER_PATTERN.test(text)) {
    return `${label} must be a whole number`;
  }
  const number = Number(text);
  if (!isPrime(number) || number > max) {
    return `${label} must be a prime number up to ${max} (2, 3, 5, 7, 11, 13 ...)`;
  }
  return undefined;
}

/** One tag: letters, digits, - and _, optionally written with a leading # (e.g. #login, bug-fix). */
const TAG_PATTERN = /^#?[A-Za-z0-9_-]+$/;

/** Tags: optional, at most maxLength characters in total, each tag made of letters, numbers, - and _. */
export function validateTags(value: string, maxLength: number): string | undefined {
  const text = value.trim();
  if (text === '') {
    return undefined;
  }
  if (text.length > maxLength) {
    return `Tags must be at most ${maxLength} characters`;
  }
  const tags = text.split(/[\s,]+/).filter((tag) => tag !== '');
  if (!tags.every((tag) => TAG_PATTERN.test(tag))) {
    return 'Tags can only contain letters, numbers, - and _ (separate tags with spaces or commas)';
  }
  return undefined;
}
