/**
 * Tags are typed by the user as "#delivery #feature" or "delivery, feature", but the backend stores them
 * as one comma-separated text ("delivery,feature"). These helpers convert between the two forms.
 */

/** "#Delivery  #feature, login" -> ["delivery", "feature", "login"] (no #, lower case, no repeats). */
export function parseTags(text: string | null): string[] {
  if (!text) {
    return [];
  }
  const tags = text
    .split(/[\s,]+/)                       // spaces or commas separate tags
    .map((tag) => tag.replace(/^#/, ''))   // remove a leading #
    .map((tag) => tag.toLowerCase())
    .filter((tag) => tag !== '');
  return [...new Set(tags)];               // a Set keeps each tag once
}

/** Form text -> what the API expects: "delivery,feature", or null when there are no tags. */
export function tagsForApi(text: string): string | null {
  const tags = parseTags(text);
  return tags.length > 0 ? tags.join(',') : null;
}

/** API text "delivery,feature" -> "#delivery #feature" (to fill the Edit form). */
export function tagsForInput(apiTags: string | null): string {
  return parseTags(apiTags)
    .map((tag) => `#${tag}`)
    .join(' ');
}
