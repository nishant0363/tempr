import { Link, useParams } from 'react-router-dom';
import { ErrorAlert } from '../../components/common/ErrorAlert';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { IssueDetailsView } from '../../components/issue/IssueDetailsView';
import { PageHeader } from '../../components/layout/PageHeader';
import { useAssigneeData } from '../../hooks/useAssigneeData';
import { useAuth } from '../../hooks/useAuth';
import { useIssue } from '../../hooks/useIssue';
import type { Issue } from '../../models/Issue';
import { PATHS } from '../../routes/paths';
import { StatusUpdateForm } from './StatusUpdateForm';

/**
 * Assignee Issue Details (Milestone 6), opened by clicking a card on the Assignee dashboard.
 * The same read-only view as the owner's, with "Issue Dashboard" in the breadcrumb and the status
 * form instead of the Edit button. Only issues assigned to the logged-in Assignee are shown.
 */
export default function AssigneeIssueDetailsPage() {
  /** The :issueId part of the URL /assignee/issues/:issueId. */
  const { issueId } = useParams();
  const { user } = useAuth();
  const { projects, reload } = useAssigneeData();
  const { issue, loading, error, reload: reloadIssue, replaceIssue } = useIssue(Number(issueId));

  /** After a status save: show the server's copy here, and refresh the board and the sidebar count. */
  function handleStatusSaved(updatedIssue: Issue): void {
    replaceIssue(updatedIssue);
    reload();
  }

  let content;
  if (loading) {
    content = <LoadingSpinner label="Loading issue..." />;
  } else if (issue === null) {
    content = (
      <>
        <ErrorAlert message={error} onRetry={reloadIssue} />
        <Link to={PATHS.ASSIGNEE_DASHBOARD}>Back to the issue dashboard</Link>
      </>
    );
  } else if (user === null || issue.assigneeId !== user.userId) {
    content = (
      <>
        <div className="alert alert-warning">Issue #{issue.issueId} is not assigned to you, so it cannot be shown here.</div>
        <Link to={PATHS.ASSIGNEE_DASHBOARD}>Back to the issue dashboard</Link>
      </>
    );
  } else {
    content = (
      <IssueDetailsView
        issue={issue}
        projectName={projects.find((p) => p.projectId === issue.projectId)?.projectName ?? `Project #${issue.projectId}`}
        assignee={user}
        breadcrumbLabel="Issue Dashboard"
        breadcrumbTo={PATHS.ASSIGNEE_DASHBOARD}
        actions={<StatusUpdateForm key={issue.issueId} issue={issue} onSaved={handleStatusSaved} />}
      />
    );
  }

  return (
    <>
      <PageHeader />
      <main className="p-4">{content}</main>
    </>
  );
}
