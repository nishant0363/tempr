import { useState } from 'react';
import { FilterSummary } from '../../components/board/FilterSummary';
import { IssueBoard } from '../../components/board/IssueBoard';
import { FlashMessage } from '../../components/common/FlashMessage';
import { PageHeader } from '../../components/layout/PageHeader';
import { useAssigneeData } from '../../hooks/useAssigneeData';
import { useAuth } from '../../hooks/useAuth';
import type { User } from '../../models/User';
import { getAssigneeIssuePath } from '../../routes/paths';
import { filterIssues } from '../../utils/issueFilters';

/**
 * Assignee dashboard (Milestone 6): every issue assigned to the logged-in Assignee, in the same
 * four-column board as the owner's, with the RegEx search in the header. Clicking a card opens
 * the Assignee's Issue Details page, where the status can be changed.
 */
export default function AssigneeDashboardPage() {
  const { user } = useAuth();
  const { issues } = useAssigneeData();

  /** Text of the header's search box. */
  const [searchText, setSearchText] = useState('');

  /** Every card shows the Assignee's own name and photo, so the look-up table holds just this user. */
  const usersById = new Map<number, User>(user ? [[user.userId, user]] : []);

  /** Issues left after the search (no other filters on this dashboard). */
  const visibleIssues = filterIssues(issues, { searchText, assigneeId: null, priority: null });

  return (
    <>
      <PageHeader searchText={searchText} onSearchChange={setSearchText} />
      <main className="p-4">
        <FlashMessage />
        <h1 className="h6 fw-bold text-uppercase mb-3">Issue Dashboard</h1>

        {issues.length === 0 && <p className="text-muted">No issues are assigned to you yet.</p>}

        <FilterSummary
          searchText={searchText}
          shownCount={visibleIssues.length}
          totalCount={issues.length}
          isFiltered={searchText.trim() !== ''}
        />

        <IssueBoard
          issues={visibleIssues}
          usersById={usersById}
          getIssueLink={(issue) => getAssigneeIssuePath(issue.issueId)}
        />
      </main>
    </>
  );
}
