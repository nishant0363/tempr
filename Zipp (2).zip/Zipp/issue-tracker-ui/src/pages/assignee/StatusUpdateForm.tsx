import { useState } from 'react';
import { ISSUE_STATUSES, STATUS_LABELS, isIssueStatus } from '../../models/Issue';
import type { Issue, IssueStatus } from '../../models/Issue';
import { getErrorMessage } from '../../services/apiClient';
import issueService from '../../services/issueService';

/** Props of StatusUpdateForm. */
interface StatusUpdateFormProps {
  issue: Issue;                          // the issue as currently saved
  onSaved: (updatedIssue: Issue) => void; // called with the server's copy after a successful save
}

/**
 * The Assignee's only change: the issue's status (case study, Assignee Issue Details).
 *  - a drop-down with the four statuses, starting at the current one
 *  - "Save Updates" is enabled only once a DIFFERENT status is chosen (and not while saving)
 *  - saving sends just { status } - the backend's PUT only changes the fields it receives
 */
export function StatusUpdateForm({ issue, onSaved }: StatusUpdateFormProps) {
  /** Status chosen in the drop-down. */
  const [selectedStatus, setSelectedStatus] = useState<IssueStatus>(issue.status);
  /** True while the request is running. */
  const [saving, setSaving] = useState(false);
  /** Error from the server ('' = none). */
  const [error, setError] = useState('');
  /** Success text after a save ('' = none). */
  const [savedMessage, setSavedMessage] = useState('');

  /** True when the chosen status differs from the saved one. */
  const hasChanged = selectedStatus !== issue.status;

  /** Drop-down change: remember the choice (checked with a type guard) and hide old messages. */
  function handleStatusChange(value: string): void {
    if (isIssueStatus(value)) {
      setSelectedStatus(value);
      setSavedMessage('');
      setError('');
    }
  }

  /** Saves the new status. */
  async function handleSave(): Promise<void> {
    if (!hasChanged || saving) {
      return;
    }
    setSaving(true);
    setError('');
    try {
      const response = await issueService.updateIssue(issue.issueId, { status: selectedStatus });
      onSaved(response.issue);
      setSavedMessage(`Status updated to ${STATUS_LABELS[response.issue.status]}.`);
    } catch (saveError) {
      setError(getErrorMessage(saveError));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="card shadow-sm">
      <div className="card-body">
        <label htmlFor="statusSelect" className="form-label small fw-semibold mb-1">
          Change status
        </label>
        <select
          id="statusSelect"
          className="form-select form-select-sm"
          value={selectedStatus}
          disabled={saving}
          onChange={(event) => handleStatusChange(event.target.value)}
        >
          {ISSUE_STATUSES.map((status) => (
            <option key={status} value={status}>
              {STATUS_LABELS[status]}
            </option>
          ))}
        </select>
        <button
          type="button"
          className="btn btn-warning btn-sm mt-2"
          disabled={!hasChanged || saving}
          onClick={handleSave}
        >
          {saving ? (
            <>
              <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
              Saving...
            </>
          ) : (
            'Save Updates'
          )}
        </button>
        {savedMessage && (
          <div className="alert alert-success py-1 px-2 small mt-2 mb-0" role="status">
            {savedMessage}
          </div>
        )}
        {error && (
          <div className="alert alert-danger py-1 px-2 small mt-2 mb-0" role="alert">
            {error}
          </div>
        )}
      </div>
    </div>
  );
}
