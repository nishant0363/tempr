import { Link } from 'react-router-dom';
import { APP_NAME } from '../appConfig';
import { PATHS } from '../routes/paths';

/** Shown for any URL that matches no route (the "*" route in App.tsx). */
export default function NotFoundPage() {
  return (
    <div>
      <header className="brand-bar text-center fw-bold py-2">{APP_NAME}</header>
      <main className="container py-5 text-center">
        <h1 className="h3">Page not found</h1>
        <p className="text-muted">The page you are looking for does not exist.</p>
        <Link to={PATHS.LOGIN} className="btn btn-warning btn-sm">
          Go to the start page
        </Link>
      </main>
    </div>
  );
}
