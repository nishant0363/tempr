import type { SelectOption } from '../../components/form/SelectField';
import { ROLES, ROLE_LABELS } from '../../models/User';

/**
 * Entries of the Role drop-down on the Login and Signup forms:
 * [{ value: 'PROJECT_OWNER', label: 'Project Owner' }, { value: 'ASSIGNEE', label: 'Assignee' }]
 */
export const ROLE_OPTIONS: SelectOption[] = ROLES.map((role) => ({
  value: role,
  label: ROLE_LABELS[role],
}));
