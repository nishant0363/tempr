import { useState } from 'react';
import type { SubmitEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { AuthLayout } from '../../components/layout/AuthLayout';
import { SelectField } from '../../components/form/SelectField';
import { SubmitButton } from '../../components/form/SubmitButton';
import { TextField } from '../../components/form/TextField';
import { useAuth } from '../../hooks/useAuth';
import { useForm } from '../../hooks/useForm';
import type { FormErrors, FormValues } from '../../hooks/useForm';
import { ROLE_LABELS, isRole } from '../../models/User';
import { isSignupSuccessState } from '../../routes/navigationState';
import { PATHS, getDashboardPath } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import userService from '../../services/userService';
import { validateEmail, validatePassword, validateRole } from '../../utils/validators';
import { ROLE_OPTIONS } from './roleOptions';

/** The fields of the login form (all strings, as HTML inputs give them). */
interface LoginFormValues extends FormValues {
  email: string;
  password: string;
  role: string;   // '' until a role is chosen, then 'PROJECT_OWNER' or 'ASSIGNEE'
}

/** Checks every field of the login form; a field without a message is valid. */
function validateLoginForm(values: LoginFormValues): FormErrors<LoginFormValues> {
  return {
    email: validateEmail(values.email),
    password: validatePassword(values.password),
    role: validateRole(values.role),
  };
}

/**
 * Login screen (Milestone 1).
 *  - email, password and role are required and validated; messages appear once a field is touched
 *  - the Login button is disabled while the form is invalid or the request is running
 *  - on success the user is remembered (AuthContext) and sent to the dashboard of their role
 *  - on failure the backend's message is shown (e.g. "Invalid email or password")
 */
export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  /** Filled when we arrive here right after a successful sign-up (success message + new email). */
  const signupState = isSignupSuccessState(location.state) ? location.state : null;

  /** Form state and validation, starting with the email from the sign-up (if any). */
  const form = useForm<LoginFormValues>(
    { email: signupState?.email ?? '', password: '', role: '' },
    validateLoginForm,
  );

  /** True while the login request is running. */
  const [submitting, setSubmitting] = useState(false);

  /** Error to show above the form (from the server, or a wrong role). Empty = no error. */
  const [serverError, setServerError] = useState('');

  /** Sends the login request when the form is submitted (button click or Enter key). */
  async function handleSubmit(event: SubmitEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();   // stop the browser's default full-page form submit
    const selectedRole = form.values.role;
    if (!form.isValid || submitting || !isRole(selectedRole)) {
      return;
    }

    setSubmitting(true);
    setServerError('');
    try {
      const response = await userService.login({
        email: form.values.email.trim(),
        password: form.values.password,
      });
      const loggedInUser = response.user;

      // The role always comes from the SERVER. The drop-down only confirms the user picked the right one.
      if (loggedInUser.role !== selectedRole) {
        setServerError(
          `This account is registered as ${ROLE_LABELS[loggedInUser.role]}. ` +
            `Please select "${ROLE_LABELS[loggedInUser.role]}" as the role.`,
        );
        return;
      }

      login(loggedInUser);
      navigate(getDashboardPath(loggedInUser.role), { replace: true });
    } catch (error) {
      setServerError(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthLayout title="Login">
      {signupState && !serverError && (
        <div className="alert alert-success py-2" role="status">
          {signupState.signupMessage}
        </div>
      )}
      {serverError && (
        <div className="alert alert-danger py-2" role="alert">
          {serverError}
        </div>
      )}

      {/* noValidate turns off the browser's own pop-up checks - our messages are used instead */}
      <form onSubmit={handleSubmit} noValidate>
        <TextField
          label="Email address"
          name="email"
          type="email"
          placeholder="Enter email"
          autoComplete="email"
          value={form.values.email}
          error={form.getError('email')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <TextField
          label="Password"
          name="password"
          type="password"
          placeholder="Password"
          autoComplete="current-password"
          value={form.values.password}
          error={form.getError('password')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <SelectField
          label="Role"
          name="role"
          placeholder="Select your role"
          options={ROLE_OPTIONS}
          value={form.values.role}
          error={form.getError('role')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
        <SubmitButton label="Login" loadingLabel="Logging in..." loading={submitting} disabled={!form.isValid} />
      </form>

      <p className="text-center small mt-4 mb-0">
        Don&apos;t have an account? <Link to={PATHS.SIGNUP}>Signup</Link>
      </p>
    </AuthLayout>
  );
}
