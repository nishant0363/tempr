import type { SelectOption } from '../../components/form/SelectField';
import type { FormErrors, FormValues } from '../../hooks/useForm';
import {
  ISSUE_STATUSES,
  ISSUE_TYPES,
  PRIORITIES,
  PRIORITY_LABELS,
  STATUS_LABELS,
  TYPE_LABELS,
  isIssueStatus,
  isIssueType,
  isPriority,
} from '../../models/Issue';
import type { Issue, IssueStatus, IssueType, Priority } from '../../models/Issue';
import type { Project } from '../../models/Project';
import { formatUserLabel } from '../../models/User';
import type { User } from '../../models/User';
import { tagsForApi, tagsForInput } from '../../utils/tagUtils';
import {
  validateOptionalLength,
  validatePositiveWholeNumber,
  validatePrimeNumber,
  validateSafeText,
  validateSelection,
  validateTags,
} from '../../utils/validators';

/**
 * Everything the Create Issue (Milestone 4) and Edit Issue (Milestone 5) forms share: the fields,
 * the limits, the validation and the conversion to the API's types. Written once, used by both,
 * so the two forms can never disagree.
 */

/** Limits of the issue fields (case study; the backend checks the same or wider limits). */
export const SUMMARY_MIN_LENGTH = 5;
export const SUMMARY_MAX_LENGTH = 100;
export const DESCRIPTION_MIN_LENGTH = 10;
export const DESCRIPTION_MAX_LENGTH = 500;
export const TAGS_MAX_LENGTH = 100;
export const SPRINT_MAX = 999;
export const STORY_POINT_MAX = 100;

/** The fields of the issue form - all text, as the inputs give them. */
export interface IssueFormValues extends FormValues {
  summary: string;
  type: string;
  projectId: string;
  description: string;
  priority: string;
  assigneeId: string;
  tags: string;        // as typed, e.g. "#delivery #feature"
  sprint: string;
  storyPoint: string;
  status: string;
}

/** A blank issue form - the start of Create Issue and what its Reset returns to. */
export const EMPTY_ISSUE_FORM: IssueFormValues = {
  summary: '',
  type: '',
  projectId: '',
  description: '',
  priority: '',
  assigneeId: '',
  tags: '',
  sprint: '',
  storyPoint: '',
  status: '',
};

/** Drop-down entries for the fixed lists (Object Value Mapping). */
export const TYPE_OPTIONS: SelectOption[] = ISSUE_TYPES.map((type) => ({ value: type, label: TYPE_LABELS[type] }));
export const PRIORITY_OPTIONS: SelectOption[] = PRIORITIES.map((p) => ({ value: p, label: PRIORITY_LABELS[p] }));
export const STATUS_OPTIONS: SelectOption[] = ISSUE_STATUSES.map((s) => ({ value: s, label: STATUS_LABELS[s] }));

/** Project drop-down entries: the owner's projects. */
export function buildProjectOptions(projects: Project[]): SelectOption[] {
  return projects.map((project) => ({ value: String(project.projectId), label: project.projectName }));
}

/** Assignee drop-down entries: every user with the Assignee role, sorted by name, shown as "Name (@username)". */
export function buildAssigneeOptions(users: User[]): SelectOption[] {
  return users
    .filter((user) => user.role === 'ASSIGNEE')
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((user) => ({ value: String(user.userId), label: formatUserLabel(user) }));
}

/**
 * Checks every field of the issue form:
 *  - summary: required, 5-100 characters, only - / | . as special characters
 *  - type, project, priority, assignee, status: must be chosen
 *  - description: optional, but 10-500 characters when filled in
 *  - tags: optional, at most 100 characters
 *  - sprint: required whole number (1, 2, 3 ...); story points: required prime number
 */
export function validateIssueForm(values: IssueFormValues): FormErrors<IssueFormValues> {
  return {
    summary: validateSafeText(values.summary, 'Summary', SUMMARY_MIN_LENGTH, SUMMARY_MAX_LENGTH),
    type: validateSelection(values.type, 'the issue type'),
    projectId: validateSelection(values.projectId, 'the project'),
    description: validateOptionalLength(values.description, 'Description', DESCRIPTION_MIN_LENGTH, DESCRIPTION_MAX_LENGTH),
    priority: validateSelection(values.priority, 'the priority'),
    assigneeId: validateSelection(values.assigneeId, 'the assignee'),
    tags: validateTags(values.tags, TAGS_MAX_LENGTH),
    sprint: validatePositiveWholeNumber(values.sprint, 'Sprint', SPRINT_MAX),
    storyPoint: validatePrimeNumber(values.storyPoint, 'Story points', STORY_POINT_MAX),
    status: validateSelection(values.status, 'the status'),
  };
}

/** The form's values converted to the types the API expects. */
export interface IssueApiFields {
  summary: string;
  description: string | null;
  projectId: number;
  assigneeId: number;
  priority: Priority;
  status: IssueStatus;
  type: IssueType;
  sprint: number;
  storyPoint: number;
  tags: string | null;
}

/**
 * Converts the (already validated) text values into typed API fields: numbers become numbers, the
 * drop-down texts are checked with type guards, empty optional texts become null.
 * Returns null if something is still not valid - the caller then sends nothing.
 */
export function toIssueApiFields(values: IssueFormValues): IssueApiFields | null {
  const { priority, status, type } = values;
  if (!isPriority(priority) || !isIssueStatus(status) || !isIssueType(type)) {
    return null;
  }
  const description = values.description.trim();
  return {
    summary: values.summary.trim(),
    description: description === '' ? null : description,
    projectId: Number(values.projectId),
    assigneeId: Number(values.assigneeId),
    priority,
    status,
    type,
    sprint: Number(values.sprint.trim()),
    storyPoint: Number(values.storyPoint.trim()),
    tags: tagsForApi(values.tags),
  };
}

/** A loaded issue as form values - the starting point of Edit Issue and what its Reset returns to. */
export function issueToFormValues(issue: Issue): IssueFormValues {
  return {
    summary: issue.summary,
    type: issue.type,
    projectId: String(issue.projectId),
    description: issue.description ?? '',
    priority: issue.priority,
    assigneeId: String(issue.assigneeId),
    tags: tagsForInput(issue.tags),
    sprint: issue.sprint === null ? '' : String(issue.sprint),
    storyPoint: String(issue.storyPoint),
    status: issue.status,
  };
}
