import { useState } from 'react';
import type { SubmitEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ErrorAlert } from '../../components/common/ErrorAlert';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { FormActions } from '../../components/form/FormActions';
import { PageHeader } from '../../components/layout/PageHeader';
import { useForm } from '../../hooks/useForm';
import { useIssue } from '../../hooks/useIssue';
import { useOwnerData } from '../../hooks/useOwnerData';
import type { Issue, UpdateIssueRequest } from '../../models/Issue';
import type { Project } from '../../models/Project';
import type { User } from '../../models/User';
import type { FlashMessageState } from '../../routes/navigationState';
import { PATHS, getOwnerIssuePath, getProjectBoardPath } from '../../routes/paths';
import { getErrorMessage } from '../../services/apiClient';
import issueService from '../../services/issueService';
import {
  buildAssigneeOptions,
  buildProjectOptions,
  issueToFormValues,
  toIssueApiFields,
  validateIssueForm,
} from './issueForm';
import type { IssueFormValues } from './issueForm';
import { IssueFormFields } from './IssueFormFields';

/** Props of EditIssueForm. */
interface EditIssueFormProps {
  issue: Issue;          // the issue as loaded - the form starts from these values
  projects: Project[];
  users: User[];
}

/**
 * The edit form itself. It is only rendered once the issue has loaded, so useForm can start from the
 * issue's values; RESET then goes back to exactly those loaded values ("initial state" in the case study).
 */
function EditIssueForm({ issue, projects, users }: EditIssueFormProps) {
  const navigate = useNavigate();

  /** Form state and validation - the same rules as Create Issue (issueForm.ts). */
  const form = useForm<IssueFormValues>(issueToFormValues(issue), validateIssueForm);
  /** True while the update request is running. */
  const [submitting, setSubmitting] = useState(false);
  /** Error from the server. Empty = no error. */
  const [serverError, setServerError] = useState('');

  /** Sends the changes; on success goes back to the Issue Details page with a message. */
  async function handleSubmit(event: SubmitEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    const fields = toIssueApiFields(form.values);
    if (!form.isValid || submitting || fields === null) {
      return;
    }

    // The backend's update only changes the fields it receives; for description and tags an empty
    // text "" means "clear it" (null would mean "leave it unchanged"), so blanks are sent as ''.
    const request: UpdateIssueRequest = {
      ...fields,
      description: fields.description ?? '',
      tags: fields.tags ?? '',
    };

    setSubmitting(true);
    setServerError('');
    try {
      await issueService.updateIssue(issue.issueId, request);
      const state: FlashMessageState = { flashMessage: `Issue #${issue.issueId} was updated successfully.` };
      navigate(getOwnerIssuePath(issue.issueId), { state });
    } catch (error) {
      setServerError(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  /** RESET: back to the values the issue had when the page was opened. */
  function handleReset(): void {
    form.reset();
    setServerError('');
  }

  return (
    <>
      {serverError && (
        <div className="alert alert-danger py-2" role="alert">
          {serverError}
        </div>
      )}
      <form onSubmit={handleSubmit} noValidate>
        <IssueFormFields
          form={form}
          projectOptions={buildProjectOptions(projects)}
          assigneeOptions={buildAssigneeOptions(users)}
        />
        <FormActions
          submitLabel="EDIT"
          submittingLabel="Saving..."
          submitting={submitting}
          canSubmit={form.isValid}
          onReset={handleReset}
        />
      </form>
    </>
  );
}

/**
 * Edit Issue screen (Milestone 5): every field of the issue, pre-filled, with the same rules as Create
 * Issue. EDIT is enabled only while every required field is valid.
 */
export default function EditIssuePage() {
  /** The :issueId part of the URL /owner/issues/:issueId/edit. */
  const { issueId } = useParams();
  const { projects, users } = useOwnerData();
  const { issue, loading, error, reload } = useIssue(Number(issueId));

  /** The issue's project, if the logged-in owner owns it. */
  const project = issue === null ? undefined : projects.find((p) => p.projectId === issue.projectId);

  let content;
  if (loading) {
    content = <LoadingSpinner label="Loading issue..." />;
  } else if (issue === null) {
    content = (
      <>
        <ErrorAlert message={error} onRetry={reload} />
        <Link to={PATHS.OWNER_DASHBOARD}>Back to the project dashboard</Link>
      </>
    );
  } else if (project === undefined) {
    content = (
      <>
        <div className="alert alert-warning">
          Issue #{issue.issueId} belongs to a project you do not own, so it cannot be edited here.
        </div>
        <Link to={PATHS.OWNER_DASHBOARD}>Back to the project dashboard</Link>
      </>
    );
  } else {
    content = (
      <>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb small mb-2">
            <li className="breadcrumb-item">
              <Link to={getProjectBoardPath(project.projectId)}>Project Board</Link>
            </li>
            <li className="breadcrumb-item">
              <Link to={getOwnerIssuePath(issue.issueId)}>Issue Details</Link>
            </li>
            <li className="breadcrumb-item active" aria-current="page">
              Edit Issue
            </li>
          </ol>
        </nav>
        <h1 className="h5 fw-bold mb-3">
          Edit Issue <span className="text-muted fs-6">#{issue.issueId}</span>
        </h1>
        {/* key: another issue id would start a fresh form */}
        <EditIssueForm key={issue.issueId} issue={issue} projects={projects} users={users} />
      </>
    );
  }

  return (
    <>
      <PageHeader />
      <main className="p-4">{content}</main>
    </>
  );
}
