import { SelectField } from '../../components/form/SelectField';
import type { SelectOption } from '../../components/form/SelectField';
import { TextAreaField } from '../../components/form/TextAreaField';
import { TextField } from '../../components/form/TextField';
import type { UseFormResult } from '../../hooks/useForm';
import { DESCRIPTION_MAX_LENGTH, PRIORITY_OPTIONS, STATUS_OPTIONS, TYPE_OPTIONS } from './issueForm';
import type { IssueFormValues } from './issueForm';

/** Props of IssueFormFields. */
interface IssueFormFieldsProps {
  form: UseFormResult<IssueFormValues>;   // the page's useForm result
  projectOptions: SelectOption[];          // the owner's projects
  assigneeOptions: SelectOption[];         // every Assignee
}

/**
 * The input fields of an issue, laid out in two columns like the case study's screenshot.
 * Reused by Create Issue (Milestone 4) and Edit Issue (Milestone 5); each page adds its own buttons.
 */
export function IssueFormFields({ form, projectOptions, assigneeOptions }: IssueFormFieldsProps) {
  return (
    <div className="row gx-4">
      <div className="col-md-6">
        <TextField
          label="Summary"
          name="summary"
          placeholder="Enter summary"
          value={form.values.summary}
          error={form.getError('summary')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <SelectField
          label="Type"
          name="type"
          placeholder="Select type"
          options={TYPE_OPTIONS}
          value={form.values.type}
          error={form.getError('type')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <SelectField
          label="Project"
          name="projectId"
          placeholder="Select project"
          options={projectOptions}
          value={form.values.projectId}
          error={form.getError('projectId')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <SelectField
          label="Priority"
          name="priority"
          placeholder="Select priority"
          options={PRIORITY_OPTIONS}
          value={form.values.priority}
          error={form.getError('priority')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-12">
        <TextAreaField
          label="Description"
          name="description"
          placeholder="Enter description"
          maxLength={DESCRIPTION_MAX_LENGTH}
          value={form.values.description}
          error={form.getError('description')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <SelectField
          label="Assignee"
          name="assigneeId"
          placeholder="Select assignee"
          options={assigneeOptions}
          value={form.values.assigneeId}
          error={form.getError('assigneeId')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <TextField
          label="Tags"
          name="tags"
          placeholder="Enter tags"
          helpText="Optional. Separate tags with spaces or commas, e.g. #delivery #feature"
          value={form.values.tags}
          error={form.getError('tags')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <TextField
          label="Sprint"
          name="sprint"
          placeholder="Enter sprint"
          inputMode="numeric"
          value={form.values.sprint}
          error={form.getError('sprint')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <TextField
          label="Story Point"
          name="storyPoint"
          placeholder="Enter story points"
          inputMode="numeric"
          helpText="Prime numbers only: 2, 3, 5, 7, 11, 13 ..."
          value={form.values.storyPoint}
          error={form.getError('storyPoint')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
      <div className="col-md-6">
        <SelectField
          label="Status"
          name="status"
          placeholder="Select status"
          options={STATUS_OPTIONS}
          value={form.values.status}
          error={form.getError('status')}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
        />
      </div>
    </div>
  );
}
