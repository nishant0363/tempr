import { useLocation, useNavigate } from 'react-router-dom';
import { isFlashMessageState } from '../../routes/navigationState';

/**
 * Green success message passed by the previous page through the router state, e.g. after a project
 * was created: navigate(path, { state: { flashMessage: '...' } }).
 * Closing it replaces the history entry WITHOUT the state, so it does not come back on a refresh.
 */
export function FlashMessage() {
  const location = useLocation();
  const navigate = useNavigate();

  /** Hides the message for good (same URL, no state). */
  function dismiss(): void {
    navigate(`${location.pathname}${location.search}`, { replace: true, state: null });
  }

  if (!isFlashMessageState(location.state)) {
    return null;
  }

  return (
    <div className="alert alert-success alert-dismissible py-2" role="status">
      <i className="bi bi-check-circle me-2" aria-hidden="true"></i>
      {location.state.flashMessage}
      <button type="button" className="btn-close py-2" aria-label="Close" onClick={dismiss}></button>
    </div>
  );
}
