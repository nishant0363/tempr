import { PRIORITY_LABELS } from '../../models/Issue';
import type { Priority } from '../../models/Issue';

/** Bootstrap colour of each priority: green = low, yellow = medium, red = high. */
const PRIORITY_CLASSES: Record<Priority, string> = {
  LOW: 'text-bg-success',
  MEDIUM: 'text-bg-warning',
  HIGH: 'text-bg-danger',
};

/** Props of PriorityBadge. */
interface PriorityBadgeProps {
  priority: Priority;
}

/** Small coloured label showing an issue's priority (issue cards, issue details). */
export function PriorityBadge({ priority }: PriorityBadgeProps) {
  return <span className={`badge ${PRIORITY_CLASSES[priority]}`}>{PRIORITY_LABELS[priority]}</span>;
}
