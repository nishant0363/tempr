import type { ChangeEvent, FocusEvent } from 'react';

/** One entry of a drop-down: the value sent to the form and the text the user sees. */
export interface SelectOption {
  value: string;
  label: string;
}

/** Props of SelectField. */
interface SelectFieldProps {
  label: string;
  name: string;
  value: string;
  options: SelectOption[];
  onChange: (event: ChangeEvent<HTMLSelectElement>) => void;
  onBlur: (event: FocusEvent<HTMLSelectElement>) => void;
  placeholder?: string;   // first, empty entry such as "Select your role"
  error?: string;
  disabled?: boolean;
  helpText?: string;      // grey hint under the drop-down, shown while there is no error
}

/**
 * Reusable labelled drop-down with a Bootstrap validation message.
 * The placeholder entry has the value "" - so "nothing chosen yet" fails a required check.
 */
export function SelectField({
  label,
  name,
  value,
  options,
  onChange,
  onBlur,
  placeholder,
  error,
  disabled = false,
  helpText,
}: SelectFieldProps) {
  /** id of the message element, linked to the drop-down for screen readers. */
  const errorId = `${name}-error`;
  /** id of the hint element. */
  const helpId = `${name}-help`;

  return (
    <div className="mb-3">
      <label htmlFor={name} className="form-label">
        {label}
      </label>
      <select
        id={name}
        name={name}
        value={value}
        disabled={disabled}
        className={`form-select ${error ? 'is-invalid' : ''}`}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : helpText ? helpId : undefined}
        onChange={onChange}
        onBlur={onBlur}
      >
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && (
        <div id={errorId} className="invalid-feedback">
          {error}
        </div>
      )}
      {!error && helpText && (
        <div id={helpId} className="form-text">
          {helpText}
        </div>
      )}
    </div>
  );
}
