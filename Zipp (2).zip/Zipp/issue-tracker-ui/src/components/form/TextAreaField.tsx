import type { ChangeEvent, FocusEvent } from 'react';

/** Props of TextAreaField. */
interface TextAreaFieldProps {
  label: string;
  name: string;
  value: string;
  onChange: (event: ChangeEvent<HTMLTextAreaElement>) => void;
  onBlur: (event: FocusEvent<HTMLTextAreaElement>) => void;
  error?: string;
  placeholder?: string;
  rows?: number;
  maxLength?: number;   // only used for the "12/500" counter; the limit itself is checked by validation
}

/** Reusable labelled multi-line text box (issue description) with a character counter. */
export function TextAreaField({
  label,
  name,
  value,
  onChange,
  onBlur,
  error,
  placeholder,
  rows = 3,
  maxLength,
}: TextAreaFieldProps) {
  /** id of the message element, linked to the text box for screen readers. */
  const errorId = `${name}-error`;

  return (
    <div className="mb-3">
      <div className="d-flex justify-content-between">
        <label htmlFor={name} className="form-label">
          {label}
        </label>
        {maxLength !== undefined && (
          <span className={`small ${value.trim().length > maxLength ? 'text-danger' : 'text-muted'}`}>
            {value.trim().length}/{maxLength}
          </span>
        )}
      </div>
      <textarea
        id={name}
        name={name}
        value={value}
        rows={rows}
        placeholder={placeholder}
        className={`form-control ${error ? 'is-invalid' : ''}`}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        onChange={onChange}
        onBlur={onBlur}
      ></textarea>
      {error && (
        <div id={errorId} className="invalid-feedback">
          {error}
        </div>
      )}
    </div>
  );
}
