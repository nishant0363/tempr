import { SubmitButton } from './SubmitButton';

/** Props of FormActions. */
interface FormActionsProps {
  submitLabel: string;       // e.g. "Create"
  submittingLabel: string;   // e.g. "Creating..."
  submitting: boolean;       // true while the API request is running
  canSubmit: boolean;        // true when the form is valid
  onReset: () => void;       // what Reset does (blank form, or back to the loaded values)
}

/**
 * The centred button pair of the create/edit forms: the yellow submit button and Reset.
 * Reset is also disabled while a request is running, so the form cannot change under it.
 */
export function FormActions({ submitLabel, submittingLabel, submitting, canSubmit, onReset }: FormActionsProps) {
  return (
    <div className="d-flex justify-content-center gap-2 mt-2">
      <SubmitButton label={submitLabel} loadingLabel={submittingLabel} loading={submitting} disabled={!canSubmit} />
      <button type="button" className="btn btn-outline-warning px-4" onClick={onReset} disabled={submitting}>
        Reset
      </button>
    </div>
  );
}
