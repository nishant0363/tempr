import { IssueColumn } from './IssueColumn';
import { ISSUE_STATUSES } from '../../models/Issue';
import type { Issue } from '../../models/Issue';
import type { User } from '../../models/User';
import { groupIssuesByStatus } from '../../utils/issueFilters';

/** Props of IssueBoard. */
interface IssueBoardProps {
  issues: Issue[];               // already filtered by the page
  usersById: Map<number, User>;
  getIssueLink?: (issue: Issue) => string;   // each role opens its own details page
}

/**
 * The four-column board (To Do, Development, Testing, Completed). Reused by the Project Owner
 * dashboard and, in Milestone 6, the Assignee dashboard. It only displays - filtering is the page's job.
 */
export function IssueBoard({ issues, usersById, getIssueLink }: IssueBoardProps) {
  const columns = groupIssuesByStatus(issues);

  return (
    <div className="issue-board">
      {ISSUE_STATUSES.map((status) => (
        <IssueColumn
          key={status}
          status={status}
          issues={columns[status]}
          usersById={usersById}
          getIssueLink={getIssueLink}
        />
      ))}
    </div>
  );
}
