import type { ReactNode } from 'react';
import { buildSearchMatcher } from '../../utils/issueFilters';

/** Props of FilterSummary. */
interface FilterSummaryProps {
  searchText: string;     // the header's search text
  shownCount: number;     // issues left after search and filters
  totalCount: number;     // all issues
  isFiltered: boolean;    // true when any search or filter is active
  children?: ReactNode;   // extra controls, e.g. the owner's "Clear filters" button
}

/**
 * Small line above a board: "Showing 2 of 5 issues" while searching/filtering, and a hint when the
 * search text is not a valid regular expression (it is then matched as plain text). Used by both dashboards.
 */
export function FilterSummary({ searchText, shownCount, totalCount, isFiltered, children }: FilterSummaryProps) {
  /** False when the search text cannot be read as a regular expression. */
  const searchIsValidRegex = buildSearchMatcher(searchText).isValidRegex;

  return (
    <div className="d-flex flex-wrap align-items-center gap-3 small text-muted mb-3">
      {isFiltered && (
        <span>
          Showing {shownCount} of {totalCount} issues
        </span>
      )}
      {children}
      {!searchIsValidRegex && (
        <span className="text-warning-emphasis">
          <i className="bi bi-info-circle me-1" aria-hidden="true"></i>
          The search text is not a valid regular expression, so it is matched as plain text.
        </span>
      )}
    </div>
  );
}
