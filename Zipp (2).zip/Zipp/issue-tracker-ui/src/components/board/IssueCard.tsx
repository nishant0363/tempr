import { Link } from 'react-router-dom';
import { Avatar } from '../common/Avatar';
import { PriorityBadge } from '../common/PriorityBadge';
import type { Issue } from '../../models/Issue';
import type { User } from '../../models/User';
import { formatDate } from '../../utils/dateUtils';

/** Props of IssueCard. */
interface IssueCardProps {
  issue: Issue;
  assignee: User | undefined;   // undefined if the assignee is not in the user list
  linkTo?: string;              // page opened when the card is clicked (its Issue Details)
}

/**
 * One issue on the board: id, creation date, title (summary), description (cut to two lines by CSS),
 * the assignee's photo and name, and the priority - the details the case study asks for.
 * With linkTo the whole card is clickable: the title is a link with Bootstrap's "stretched-link",
 * whose click area is stretched over the entire card.
 */
export function IssueCard({ issue, assignee, linkTo }: IssueCardProps) {
  /** Name to show; a placeholder if the user could not be found. */
  const assigneeName = assignee?.name ?? `User #${issue.assigneeId}`;

  return (
    <article className={`card issue-card shadow-sm ${linkTo ? 'issue-card-clickable' : ''}`}>
      <div className="card-body p-2">
        <div className="d-flex justify-content-between small text-muted">
          <span className="fw-semibold text-dark">#{issue.issueId}</span>
          <span>{formatDate(issue.createdOn)}</span>
        </div>
        <h4 className="issue-card-title">
          {linkTo ? (
            <Link to={linkTo} className="stretched-link text-reset text-decoration-none">
              {issue.summary}
            </Link>
          ) : (
            issue.summary
          )}
        </h4>
        {issue.description && <p className="issue-card-description">{issue.description}</p>}
        <div className="d-flex justify-content-between align-items-center gap-2">
          <span className="d-flex align-items-center gap-1 small text-truncate">
            <Avatar name={assigneeName} imageUrl={assignee?.profile ?? null} size={22} />
            <span className="text-truncate" title={assignee ? `@${assignee.username}` : undefined}>
              {assigneeName}
            </span>
          </span>
          <PriorityBadge priority={issue.priority} />
        </div>
      </div>
    </article>
  );
}
