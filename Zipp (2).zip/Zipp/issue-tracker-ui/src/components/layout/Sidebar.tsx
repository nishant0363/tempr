import { NavLink, useNavigate } from 'react-router-dom';
import { APP_SHORT_NAME } from '../../appConfig';
import { Avatar } from '../common/Avatar';
import { useAuth } from '../../hooks/useAuth';
import { PATHS } from '../../routes/paths';

/** One number shown under the profile, e.g. { label: 'Projects Created', value: 3 }. */
export interface SidebarStat {
  label: string;
  value: number | string;
}

/** One navigation link, e.g. { to: '/owner/projects/new', label: 'Create Project', icon: 'bi-plus-square' }. */
export interface SidebarLink {
  to: string;
  label: string;
  icon: string;   // Bootstrap Icons class name
}

/** Props of Sidebar. */
interface SidebarProps {
  stats: SidebarStat[];
  links: SidebarLink[];   // empty for the Assignee, who has only the dashboard
}

/**
 * Dark left-hand panel of the logged-in pages, reused by both roles:
 * the user's photo, name, @username and email, their numbers (projects/issues), the navigation links and Logout.
 * NavLink adds the "active" class to the link of the page currently shown.
 */
export function Sidebar({ stats, links }: SidebarProps) {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  /** Logs out and goes back to the Login page. */
  function handleLogout(): void {
    logout();
    navigate(PATHS.LOGIN, { replace: true });
  }

  // Only shown inside ProtectedRoute, so a user exists - this check is for TypeScript
  if (user === null) {
    return null;
  }

  return (
    <aside className="sidebar d-flex flex-column">
      {/* Logo mark + app name */}
      <div className="sidebar-brand d-flex align-items-center gap-2 px-3 pt-3">
        <span className="brand-mark" aria-hidden="true">IC</span>
        <span className="fw-bold">{APP_SHORT_NAME}</span>
      </div>
      <div className="text-center px-3 pt-3">
        <Avatar name={user.name} imageUrl={user.profile} size={72} />
        <div className="fw-bold text-white mt-2">{user.name}</div>
        <div className="small text-white-50">@{user.username}</div>
        <div className="small sidebar-email text-break">{user.email}</div>

        <div className="d-flex justify-content-around gap-3 mt-3">
          {stats.map((stat) => (
            <div key={stat.label} className="sidebar-stat">
              <div className="fs-4 fw-bold text-white lh-1">{stat.value}</div>
              <div className="small text-white-50 sidebar-stat-label">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {links.length > 0 && (
        <nav className="nav flex-column mt-4 px-2" aria-label="Main navigation">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end
              className={({ isActive }) => `nav-link sidebar-link ${isActive ? 'active' : ''}`}
            >
              <i className={`bi ${link.icon} me-2`} aria-hidden="true"></i>
              {link.label}
            </NavLink>
          ))}
        </nav>
      )}

      <div className="mt-auto p-3">
        <button type="button" className="btn btn-outline-warning btn-sm" onClick={handleLogout}>
          <i className="bi bi-box-arrow-right me-1" aria-hidden="true"></i>
          Logout
        </button>
        <div className="sidebar-credit mt-3">crafted by Nishant</div>
      </div>
    </aside>
  );
}
