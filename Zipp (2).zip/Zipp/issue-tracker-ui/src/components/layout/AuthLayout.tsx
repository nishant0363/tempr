import type { ReactNode } from 'react';
import { APP_NAME } from '../../appConfig';

/** Props of AuthLayout. */
interface AuthLayoutProps {
  title: string;        // card heading, e.g. "Login"
  children: ReactNode;  // the form shown inside the card
}

/**
 * Shared page frame of the Login and Signup screens: the yellow application bar on top and a
 * centred card with a grey title row, as in the case study's screenshots.
 */
export function AuthLayout({ title, children }: AuthLayoutProps) {
  return (
    <div className="auth-page">
      <header className="brand-bar text-center fw-bold py-2">{APP_NAME}</header>
      <main className="container py-5">
        <div className="card auth-card mx-auto shadow-sm">
          <h1 className="card-header text-center fs-5 fw-normal mb-0">{title}</h1>
          <div className="card-body p-4">{children}</div>
        </div>
      </main>
    </div>
  );
}
