/**
 * TypeScript models for the User Service. They describe the JSON the backend sends and expects,
 * exactly like the Java DTO records (UserResponse, LoginRequest, SignUpRequest ...).
 * Types exist only while coding: they are removed when the app is built, so they cost nothing at runtime.
 */

/**
 * The two kinds of users - the same text values the backend uses for its Role enum.
 * A "union type" of string literals is the usual TypeScript replacement for a Java enum.
 */
export type Role = 'PROJECT_OWNER' | 'ASSIGNEE';

/** Every role, in the order they appear in drop-downs. */
export const ROLES: Role[] = ['PROJECT_OWNER', 'ASSIGNEE'];

/** The text shown on screen for each role. Record<Role, string> forces an entry for every role. */
export const ROLE_LABELS: Record<Role, string> = {
  PROJECT_OWNER: 'Project Owner',
  ASSIGNEE: 'Assignee',
};

/** A user as the backend returns it (UserResponse). It never contains the password. */
export interface User {
  userId: number;
  username: string;         // unique handle in lower case, e.g. "priya"
  name: string;             // full name for display - two users may have the same name
  email: string;
  profile: string | null;   // profile image URL (older accounts may have none)
  role: Role;
}

/** Body of POST /api/users/login. */
export interface LoginRequest {
  email: string;
  password: string;
}

/** Answer of a successful login. */
export interface LoginResponse {
  message: string;
  user: User;
}

/** Body of POST /api/users (sign up). */
export interface SignUpRequest {
  username: string;
  name: string;
  email: string;
  password: string;
  profile: string | null;   // optional photo URL - null when the user did not give one
  role: Role;
}

/** Answer of a successful sign-up. */
export interface SignUpResponse {
  message: string;
  loginUrl: string;
  user: User;
}

/**
 * Type guard: checks at RUNTIME that a plain string is one of our roles.
 * After `if (isRole(text))` TypeScript treats `text` as a Role instead of any string.
 */
export function isRole(value: string): value is Role {
  return ROLES.includes(value as Role);
}

/**
 * Type guard for data we did not create ourselves (for example the user saved in sessionStorage):
 * checks that it really has the shape of a User before the app trusts it.
 */
export function isUser(value: unknown): value is User {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  const candidate = value as Partial<User>;
  return (
    typeof candidate.userId === 'number' &&
    typeof candidate.username === 'string' &&
    typeof candidate.name === 'string' &&
    typeof candidate.email === 'string' &&
    typeof candidate.role === 'string' &&
    isRole(candidate.role)
  );
}

/**
 * How a user is written in drop-downs and filters: "Priya Sharma (@priya)".
 * Names may repeat, so the unique username is added to tell two people with the same name apart.
 */
export function formatUserLabel(user: User): string {
  return `${user.name} (@${user.username})`;
}
