/** The application's name, shown in the header bars and the browser tab. One place to change it. */
export const APP_NAME = 'InfinityCastle - Issue Tracker';

/** Short name for the logo mark in the sidebar. */
export const APP_SHORT_NAME = 'InfinityCastle';
