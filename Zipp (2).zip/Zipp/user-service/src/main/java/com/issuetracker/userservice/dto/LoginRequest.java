package com.issuetracker.userservice.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

/**
 * JSON body of POST /api/users/login.
 * Assumption: login uses email + password (the case study's login field list repeats the sign-up fields,
 * but only these two are needed to identify and check a user).
 */
public record LoginRequest(

        @Schema(example = "priya@its.com")
        @NotBlank(message = "Email is required")
        @Email(message = "Email must be a valid email address")
        String email,

        @Schema(example = "Owner@123")
        @NotBlank(message = "Password is required")
        String password) {
}
