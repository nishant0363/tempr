package com.issuetracker.userservice.dto;

import com.issuetracker.userservice.entity.Role;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * JSON body of POST /api/users (sign up).
 *
 * A Java "record" is a small, read-only data class: Java generates the constructor, the accessors
 * (name(), email() ...), equals, hashCode and toString for us.
 *
 * The validation annotations are checked automatically because the controller marks the body with @Valid.
 * If any rule fails, Spring throws MethodArgumentNotValidException and our GlobalExceptionHandler
 * answers 400 Bad Request with one message per invalid field.
 *
 * @Schema(example = ...) only fills in the sample JSON shown in Swagger UI.
 *
 * Week 4: the React sign-up form asks for a "proper password format" and, when one is given, a valid
 * profile image URL (the photo is optional - without one the screens show the user's initials).
 * The same rules are checked here too, so a request that skips the browser (Swagger, Postman, a script)
 * cannot store a weak password or a broken image link.
 */
public record SignUpRequest(

        @Schema(example = "meera.n",
                description = "Unique handle: 3-30 letters, numbers, dot, underscore or hyphen (stored in lower case)")
        @NotBlank(message = "Username is required")
        @Pattern(regexp = "^[A-Za-z0-9._-]{3,30}$",
                message = "Username must be 3 to 30 characters: letters, numbers, dot, underscore or hyphen (no spaces)")
        String username,

        @Schema(example = "Meera Nair", description = "Full name for display - does not need to be unique")
        @NotBlank(message = "Name is required")
        @Size(max = 100, message = "Name must be at most 100 characters")
        String name,

        @Schema(example = "meera@its.com")
        @NotBlank(message = "Email is required")
        @Email(message = "Email must be a valid email address")
        @Size(max = 255, message = "Email must be at most 255 characters")
        String email,

        @Schema(example = "Meera@123",
                description = "8-64 characters with an uppercase letter, a lowercase letter, a number and a special character")
        @NotBlank(message = "Password is required")
        // (?=.*[a-z]) means "somewhere there is a lower-case letter"; the four look-aheads are the four
        // character rules and .{8,64} is the length rule
        @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,64}$",
                message = "Password must be 8 to 64 characters and contain an uppercase letter, a lowercase letter, "
                        + "a number and a special character")
        String password,

        @Schema(example = "https://randomuser.me/api/portraits/women/65.jpg",
                description = "Optional profile image URL: http(s), ending in .png, .jpg, .jpeg, .gif, .webp or .svg")
        @Size(max = 255, message = "Profile image URL must be at most 255 characters")
        // "^\\s*$|" lets an empty (or blank) value through - it is stored as NULL; anything else must be an image URL.
        // A missing (null) value is always valid for @Pattern.
        @Pattern(regexp = "^\\s*$|^https?://\\S+\\.(png|jpe?g|gif|webp|svg)(\\?\\S*)?$",
                flags = Pattern.Flag.CASE_INSENSITIVE,
                message = "Profile must be an image URL starting with http:// or https:// and ending in "
                        + ".png, .jpg, .jpeg, .gif, .webp or .svg")
        String profile,

        @Schema(example = "ASSIGNEE", description = "PROJECT_OWNER or ASSIGNEE")
        @NotNull(message = "Role is required (PROJECT_OWNER or ASSIGNEE)")
        Role role) {
}
