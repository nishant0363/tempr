package com.issuetracker.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Entry point of the User microservice (port 8081).
 *
 * @SpringBootApplication = @Configuration + @EnableAutoConfiguration + @ComponentScan.
 * Spring Boot scans this package and its sub-packages (controller, service, repository ...),
 * creates the beans, connects to MySQL and starts an embedded Tomcat - no external server needed.
 *
 * @EnableFeignClients (Milestone 5) tells Spring Cloud to look for interfaces annotated with @FeignClient
 * (here: client.IssueClient) and generate their implementations - the code that makes the HTTP calls.
 */
@SpringBootApplication
@EnableFeignClients
public class UserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }
}
