package com.issuetracker.userservice.exception;

/**
 * Thrown when login fails. GlobalExceptionHandler turns it into 401 Unauthorized.
 *
 * The same message is used for "unknown email" and "wrong password" on purpose:
 * telling them apart would let someone discover which emails are registered.
 */
public class InvalidCredentialsException extends RuntimeException {

    public InvalidCredentialsException(String message) {
        super(message);
    }
}
