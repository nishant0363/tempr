package com.issuetracker.userservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * General beans for this service.
 * A @Bean method's return value is managed by Spring and can be injected anywhere it is needed.
 */
@Configuration
public class AppConfig {

    /**
     * BCrypt password hashing. Declared as the PasswordEncoder INTERFACE so the algorithm could be
     * swapped later without changing the classes that use it.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
