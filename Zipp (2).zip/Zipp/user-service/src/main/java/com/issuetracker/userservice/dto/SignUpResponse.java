package com.issuetracker.userservice.dto;

/**
 * Response of a successful sign-up.
 * The case study asks for the message "Your account is created successfully" with a link to login;
 * in a REST API that link is simply the login endpoint's URL, which a frontend can turn into a hyperlink.
 */
public record SignUpResponse(
        String message,
        String loginUrl,
        UserResponse user) {
}
