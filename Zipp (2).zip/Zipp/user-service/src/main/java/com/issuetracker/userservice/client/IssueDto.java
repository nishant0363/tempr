package com.issuetracker.userservice.client;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * An issue as returned by the Issue Service (its IssueResponse JSON).
 *
 * Microservices share no code, so this service keeps its OWN copy of the shape it receives.
 * priority/status/type are plain Strings here: the User Service only passes them on, it does not need
 * the Issue Service's enums. @JsonIgnoreProperties(ignoreUnknown = true) means that if the Issue Service
 * adds new fields later, this service keeps working instead of failing to read the JSON.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record IssueDto(
        Integer issueId,
        String summary,
        String description,
        Integer projectId,
        Integer assigneeId,
        Integer createdBy,
        String priority,
        String status,
        String type,
        Integer sprint,
        Integer storyPoint,
        String tags,
        LocalDate createdOn,
        LocalDateTime lastUpdated) {
}
